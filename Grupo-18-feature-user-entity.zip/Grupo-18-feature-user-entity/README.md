**Integrantes:**
- Vladimir Sagredo 202173553-4
- Oscar Valverde 202173623-9
- Javier Gomez 202173519-4


***Instrucciones de uso:***

Entidades por VM:
- dist069: ANBU y RabbitMQ
- dist070: Akatsuki
- dist071: Hokage
- dist072: NinjaTeam

**Para correr cada entidad existe un makefile en cada VM en una carpeta llamada como la entidad**

Estos son los comandos para las primeras 3 entidades (Anbu y rabbit,Akatsuki,Hokage):

**Levantar y correr entidades**
- make build --> sudo docker-compose build --no-cache
- make up --> sudo docker-compose up -d
  
**bajar entidad**
- make down --> sudo docker-compose down

**mostrar logs**
- make logs --> sudo docker-compose logs -f akatsuki

**reiniciar entidad**
- make restart --> sudo docker-compose down && sudo docker-compose up -d

Para la entidad ninja, son casi los mismos:

**levantar y correr entidad**
- make build --> sudo docker-compose build --no-cache
- make run --> sudo docker-compose run ninjateam

**bajar entidad**
- make down --> sudo docker-compose down

**reiniciar entidad**
- make restart --> sudo docker-compose down && sudo docker-compose run ninjateam

Para correrlo, solo es necesario abrir cada vm en una terminal, hacer cd en la única carpeta de cada vm y ejecutar los comandos, los cuales, los más importantes corresponen a los de "levantar y correr entidades" para iniciar cada entidad.

make logs sirve para visualizar los logs que ocurren por detras , disponible para las primeras 3 entidades. **Por favor respetar en que VM se levanta cada entidad, indicadas en las instrucciones de uso, ademas de respetar el orden de levantamiento según aparecen en las instrucciones de uso**
