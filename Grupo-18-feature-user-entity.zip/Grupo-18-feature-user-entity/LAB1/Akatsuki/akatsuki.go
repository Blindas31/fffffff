package main

import (
	pb "akatsuki/proto/grpc_ninja/proto"
	"context"
	"encoding/json"
	"fmt"
	"log"
	"math/rand/v2"
	"net"
	"os"
	"sync"
	"time"

	"github.com/google/uuid"
	amqp "github.com/rabbitmq/amqp091-go"
	"google.golang.org/grpc"
)

// Estructuras necesarias
type Akatsuki struct {
	HP     int
	ATK    int
	Status string
}

type Publisher struct {
	conn    *amqp.Connection
	channel *amqp.Channel
}

type server struct {
	pb.UnimplementedSendAtaqueServer
	publisher *Publisher
}

type AkatsukiEvent struct {
	ID        string    `json:"id"`
	EventType string    `json:"event_type"`
	Nombre    string    `json:"nombre"`
	HP        int       `json:"hp"`
	ATK       int       `json:"atk"`
	Status    string    `json:"status"`
	Timestamp time.Time `json:"timestamp"`
}

func printCombatHeader(nombreNinja, nombreAkatsuki string) {
	const line = "============================================================"
	fmt.Println(line)
	fmt.Println("==                     LOGS DEL COMBATE                   ==")
	fmt.Println(line)
	fmt.Println()
	fmt.Println("Comienza Combate")
	fmt.Printf("Equipo %s vs %s\n", nombreNinja, nombreAkatsuki)
	fmt.Println()
}

func printCombatFooter() {
	fmt.Println()
	fmt.Println("Combate finalizado")
	fmt.Println("============================================================")
}

// Constantes y variables
const (
	QueueAppeared = "akatsuki.appeared"
	QueueUpdated  = "akatsuki.updated"
)

var todosLosAkatsukis = []struct {
	nombre   string
	akatsuki Akatsuki
}{
	{"Itachi Uchiha", Akatsuki{280, 135, "Localizado"}},
	{"Kisame Hoshigaki", Akatsuki{200, 90, "Localizado"}},
	{"Deidara", Akatsuki{150, 85, "Localizado"}},
	{"Sasori", Akatsuki{160, 80, "Localizado"}},
	{"Hidan", Akatsuki{170, 75, "Localizado"}},
	{"Kakuzu", Akatsuki{190, 70, "Localizado"}},
	{"Konan", Akatsuki{140, 65, "Localizado"}},
	{"Pain", Akatsuki{210, 100, "Localizado"}},
	{"Zetsu", Akatsuki{130, 60, "Localizado"}},
	{"Tobi", Akatsuki{220, 110, "Localizado"}},
	{"Madara Uchiha", Akatsuki{300, 150, "Localizado"}},
}

var (
	akatsukisGenerados = map[string]Akatsuki{}
	mu                 sync.RWMutex
)

func generarAkatsukis(publisher *Publisher) {
	for _, entrada := range todosLosAkatsukis {
		mu.Lock()
		akatsukisGenerados[entrada.nombre] = entrada.akatsuki
		fmt.Printf("\n→ %s apareció! HP: %d, ATK: %d\n", entrada.nombre, entrada.akatsuki.HP, entrada.akatsuki.ATK)

		event := AkatsukiEvent{
			ID:        uuid.New().String(),
			EventType: QueueAppeared,
			Nombre:    entrada.nombre,
			HP:        entrada.akatsuki.HP,
			ATK:       entrada.akatsuki.ATK,
			Status:    entrada.akatsuki.Status,
			Timestamp: time.Now(),
		}

		if err := publisher.Publish(QueueAppeared, event); err != nil {
			log.Printf("error publicando aparición de %s: %v", entrada.nombre, err)
		}

		fmt.Printf("Total akatsukis activos: %d\n", len(akatsukisGenerados))
		mu.Unlock()

		time.Sleep(15 * time.Second)
	}

	fmt.Println("\n¡Todos los Akatsukis han aparecido!")
}

func refreshAkatsukis(publisher *Publisher) {
	for {
		mu.Lock()
		activos := make([]struct {
			nombre   string
			akatsuki Akatsuki
		}, 0, len(akatsukisGenerados))

		for nombre, akatsuki := range akatsukisGenerados {
			activos = append(activos, struct {
				nombre   string
				akatsuki Akatsuki
			}{nombre: nombre, akatsuki: akatsuki})
		}
		mu.Unlock()

		if len(activos) == 0 {
			time.Sleep(5 * time.Second)
			continue
		}

		for _, entrada := range activos {
			fmt.Printf("\n→ %s sigue activo! HP: %d, ATK: %d, Status: %s\n",
				entrada.nombre, entrada.akatsuki.HP, entrada.akatsuki.ATK, entrada.akatsuki.Status)

			event := AkatsukiEvent{
				ID:        uuid.New().String(),
				EventType: QueueUpdated,
				Nombre:    entrada.nombre,
				HP:        entrada.akatsuki.HP,
				ATK:       entrada.akatsuki.ATK,
				Status:    entrada.akatsuki.Status,
				Timestamp: time.Now(),
			}

			if err := publisher.Publish(QueueUpdated, event); err != nil {
				log.Printf("error publicando estado de %s: %v", entrada.nombre, err)
			}

			time.Sleep(5 * time.Second)
		}

		time.Sleep(10 * time.Second)
	}
}

func actualizarEstado(publisher *Publisher, nombre string, nuevoStatus string) error {
	mu.Lock()
	defer mu.Unlock()

	akatsuki, existe := akatsukisGenerados[nombre]
	if !existe {
		return fmt.Errorf("akatsuki %s no encontrado", nombre)
	}

	akatsuki.Status = nuevoStatus
	akatsukisGenerados[nombre] = akatsuki

	event := AkatsukiEvent{
		ID:        uuid.New().String(),
		EventType: QueueUpdated,
		Nombre:    nombre,
		HP:        akatsuki.HP,
		ATK:       akatsuki.ATK,
		Status:    nuevoStatus,
		Timestamp: time.Now(),
	}

	return publisher.Publish(QueueUpdated, event)
}

func showAkatsukis() {
	mu.RLock()
	defer mu.RUnlock()

	fmt.Println("\nAkatsukis activos:")
	for nombre, akatsuki := range akatsukisGenerados {
		fmt.Printf("  → %s: HP: %d, ATK: %d, Status: %s\n", nombre, akatsuki.HP, akatsuki.ATK, akatsuki.Status)
	}
}

// ======================== Publisher ======================== //

func connectionCreate(amqpUrl string) (*Publisher, error) {
	conn, err := amqp.Dial(amqpUrl)
	if err != nil {
		return nil, err
	}
	ch, err := conn.Channel()
	if err != nil {
		conn.Close()
		return nil, err
	}
	return &Publisher{conn: conn, channel: ch}, nil
}

func connectWithRetry(amqpUrl string, maxRetries int) (*Publisher, error) {
	var publisher *Publisher
	var err error
	for i := 0; i < maxRetries; i++ {
		publisher, err = connectionCreate(amqpUrl)
		if err == nil {
			return publisher, nil
		}
		log.Printf("RabbitMQ no disponible, reintentando en 5s... (%d/%d)", i+1, maxRetries)
		time.Sleep(5 * time.Second)
	}
	return nil, err
}

func (p *Publisher) Publish(queueName string, body interface{}) error {
	_, err := p.channel.QueueDeclare(
		queueName,
		true,
		false,
		false,
		false,
		nil,
	)
	if err != nil {
		return fmt.Errorf("failed to declare queue: %v", err)
	}

	data, err := json.Marshal(body)
	if err != nil {
		return fmt.Errorf("failed to marshal body: %v", err)
	}

	return p.channel.PublishWithContext(
		context.Background(),
		"",
		queueName,
		false,
		false,
		amqp.Publishing{
			ContentType:  "application/json",
			DeliveryMode: amqp.Persistent,
			MessageId:    uuid.New().String(),
			Timestamp:    time.Now(),
			Body:         data,
		},
	)
}

func (p *Publisher) Close() {
	p.channel.Close()
	p.conn.Close()
}

func (s *server) Combate(stream pb.SendAtaque_CombateServer) error {
	req, err := stream.Recv()
	if err != nil {
		return err
	}

	nombreAkatsuki := req.NombreAkatsuki
	nombreNinja := req.NombreNinjateam

	mu.Lock()
	akatsuki, existe := akatsukisGenerados[nombreAkatsuki]
	if !existe {
		mu.Unlock()
		return fmt.Errorf("akatsuki %s no encontrado", nombreAkatsuki)
	}
	if akatsuki.Status != "Localizado" {
		mu.Unlock()
		return fmt.Errorf("akatsuki %s no disponible, status: %s", nombreAkatsuki, akatsuki.Status)
	}
	hpOriginalAkatsuki := akatsuki.HP
	akatsuki.Status = "En Combate"

	s.publisher.Publish(QueueUpdated, AkatsukiEvent{
		ID:        uuid.New().String(),
		EventType: QueueUpdated,
		Nombre:    nombreAkatsuki,
		HP:        hpOriginalAkatsuki,
		ATK:       akatsuki.ATK,
		Status:    akatsuki.Status,
		Timestamp: time.Now(),
	})
	akatsukisGenerados[nombreAkatsuki] = akatsuki
	mu.Unlock()

	printCombatHeader(nombreNinja, nombreAkatsuki)

	for {
		multiplicador := 0.5 + rand.Float64()*1.5
		danoNinja := int(float64(req.Ataque) * multiplicador)
		acierto := rand.Float64() < 0.7

		mu.Lock()
		akatsuki = akatsukisGenerados[nombreAkatsuki]
		fmt.Printf("Equipo %s atacó\n", nombreNinja)
		var mensajeTurnoNinja string
		if acierto {
			akatsuki.HP -= danoNinja
			mensajeTurnoNinja = fmt.Sprintf("%s recibe daño, Vida = %d", nombreAkatsuki, akatsuki.HP)
		} else {
			mensajeTurnoNinja = fmt.Sprintf("%s esquivó el ataque", nombreAkatsuki)
		}
		fmt.Println(mensajeTurnoNinja)
		fmt.Println()
		if akatsuki.HP <= 0 {
			akatsuki.HP = 0
			akatsuki.Status = "Capturado"
			akatsukisGenerados[nombreAkatsuki] = akatsuki
			mu.Unlock()
			s.publisher.Publish(QueueUpdated, AkatsukiEvent{
				ID:        uuid.New().String(),
				EventType: QueueUpdated,
				Nombre:    nombreAkatsuki,
				HP:        0,
				ATK:       akatsuki.ATK,
				Status:    "Capturado",
				Timestamp: time.Now(),
			})
			printCombatFooter()
			stream.Send(&pb.CombateResponse{
				Message:        fmt.Sprintf("%s\n%s fue capturado. Combate finalizado", mensajeTurnoNinja, nombreAkatsuki),
				HpAkatsuki:     0,
				AtaqueAkatsuki: 0,
				Resultado:      "victoria",
			})
			return nil
		}
		akatsukisGenerados[nombreAkatsuki] = akatsuki
		mu.Unlock()

		if rand.Float64() < 0.10 {
			mu.Lock()
			akatsuki = akatsukisGenerados[nombreAkatsuki]
			akatsuki.HP = hpOriginalAkatsuki
			akatsuki.Status = "Localizado"
			akatsukisGenerados[nombreAkatsuki] = akatsuki
			mu.Unlock()
			s.publisher.Publish(QueueUpdated, AkatsukiEvent{
				ID:        uuid.New().String(),
				EventType: QueueUpdated,
				Nombre:    nombreAkatsuki,
				HP:        hpOriginalAkatsuki,
				ATK:       akatsuki.ATK,
				Status:    "Localizado",
				Timestamp: time.Now(),
			})
			printCombatFooter()
			stream.Send(&pb.CombateResponse{
				Message:        fmt.Sprintf("%s\n%s escapó. Combate finalizado", mensajeTurnoNinja, nombreAkatsuki),
				HpAkatsuki:     int32(hpOriginalAkatsuki),
				AtaqueAkatsuki: 0,
				Resultado:      "escapo",
			})
			return nil
		}

		multiplicadorAtk := 0.5 + rand.Float64()*1.5
		danoAkatsuki := int(float64(akatsuki.ATK) * multiplicadorAtk)
		aciertoAtk := rand.Float64() < 0.7

		fmt.Printf("%s atacó\n", nombreAkatsuki)
		var mensajeTurnoAkatsuki string
		if aciertoAtk {
			mensajeTurnoAkatsuki = fmt.Sprintf("Equipo %s recibe daño", nombreNinja)
		} else {
			mensajeTurnoAkatsuki = fmt.Sprintf("Equipo %s esquivó el ataque", nombreNinja)
			danoAkatsuki = 0
		}
		fmt.Println(mensajeTurnoAkatsuki)
		fmt.Println()
		time.Sleep(500 * time.Millisecond)
		stream.Send(&pb.CombateResponse{
			Message:        fmt.Sprintf("%s\n%s", mensajeTurnoNinja, mensajeTurnoAkatsuki),
			HpAkatsuki:     int32(akatsuki.HP),
			AtaqueAkatsuki: int32(danoAkatsuki),
			Resultado:      "en_curso",
		})

		req, err = stream.Recv()
		if err != nil || req.Ataque == -1 {
			mu.Lock()
			akatsuki = akatsukisGenerados[nombreAkatsuki]
			akatsuki.HP = hpOriginalAkatsuki
			akatsuki.Status = "Localizado"
			akatsukisGenerados[nombreAkatsuki] = akatsuki
			mu.Unlock()
			s.publisher.Publish(QueueUpdated, AkatsukiEvent{
				ID:        uuid.New().String(),
				EventType: QueueUpdated,
				Nombre:    nombreAkatsuki,
				HP:        hpOriginalAkatsuki,
				ATK:       akatsuki.ATK,
				Status:    "Localizado",
				Timestamp: time.Now(),
			})
			log.Printf("[Akatsuki] %s volvió a Localizado", nombreAkatsuki)
			printCombatFooter()
			return nil
		}
	}
}

func main() {
	amqpUrl := os.Getenv("RABBITMQ_URL")
	if amqpUrl == "" {
		amqpUrl = "amqp://guest:guest@localhost:5672/"
	}
	publisher, err := connectWithRetry(amqpUrl, 5)
	if err != nil {
		log.Fatalf("error conectando a RabbitMQ: %v", err)
	}
	defer publisher.Close()

	// ======================== gRPC ======================== //
	lis, err := net.Listen("tcp", ":50051")
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}
	grpcServer := grpc.NewServer()
	pb.RegisterSendAtaqueServer(grpcServer, &server{publisher: publisher})
	log.Printf("[Akatsuki] gRPC escuchando en :50051")
	go func() {
		if err := grpcServer.Serve(lis); err != nil {
			log.Fatalf("failed to serve: %v", err)
		}
	}()

	go func() {
		time.Sleep(60 * time.Second)
		refreshAkatsukis(publisher)
	}()
	go generarAkatsukis(publisher)
	select {}
}
