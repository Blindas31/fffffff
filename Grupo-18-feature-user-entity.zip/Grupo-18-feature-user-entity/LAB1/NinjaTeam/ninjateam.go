package main

import (
	"bufio"
	"context"
	"fmt"
	"log"
	pb1 "ninjateam/proto/grpc_akatsuki/proto"
	pb "ninjateam/proto/grpc_hokage/proto"
	"os"
	"strconv"
	"strings"
	"time"

	amqp "github.com/rabbitmq/amqp091-go"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

type NinjaTeam struct {
	name   string
	attack int
	hp     int
	saldo  int
}
type HandlerFunc func(ctx context.Context, body []byte) error

type Consumer struct {
	conn    *amqp.Connection
	channel *amqp.Channel
}
type AkatsukiCapturado struct {
	nombre string
	bounty int
}

var capturados []AkatsukiCapturado

func createNinjaTeam(name string, attack int, hp int, saldo int) NinjaTeam {
	return NinjaTeam{
		name:   name,
		attack: attack,
		hp:     hp,
		saldo:  saldo,
	}
}

func connectConsumerWithRetry(amqpUrl string, maxRetries int) (*Consumer, error) {
	var consumer *Consumer
	var err error
	for i := 0; i < maxRetries; i++ {
		consumer, err = createConsumer(amqpUrl)
		if err == nil {
			return consumer, nil
		}
		log.Printf("RabbitMQ no disponible, reintentando consumer en 5s... (%d/%d)", i+1, maxRetries)
		time.Sleep(5 * time.Second)
	}
	return nil, err
}

func createConsumer(amqpUrl string) (*Consumer, error) {
	conn, err := amqp.Dial(amqpUrl)
	if err != nil {
		return nil, fmt.Errorf("failed to connect to RabbitMQ: %v", err)
	}
	ch, err := conn.Channel()
	if err != nil {
		conn.Close()
		return nil, fmt.Errorf("failed to create channel: %v", err)
	}
	if err := ch.Qos(1, 0, false); err != nil {
		conn.Close()
		return nil, fmt.Errorf("failed to set QoS: %v", err)
	}
	return &Consumer{conn: conn, channel: ch}, nil
}

func (c *Consumer) Listen(ctx context.Context, queueName string, handler HandlerFunc) error {
	_, err := c.channel.QueueDeclare(
		queueName,
		true,
		false,
		false,
		false,
		nil,
	)
	if err != nil {
		return fmt.Errorf("failed to declare queue: %v", err)
	}

	msgs, err := c.channel.Consume(
		queueName,
		"",
		false,
		false,
		false,
		false,
		nil,
	)
	if err != nil {
		return fmt.Errorf("failed to register consumer: %v", err)
	}

	log.Printf("ANBU escuchando en la cola: %s", queueName)

	for {
		select {
		case <-ctx.Done():
			return nil
		case d, ok := <-msgs:
			if !ok {
				return fmt.Errorf("channel closed")
			}
			go func(delivery amqp.Delivery) {
				if err := handler(ctx, delivery.Body); err != nil {
					log.Printf("error procesando mensaje: %v", err)
					delivery.Nack(false, false)
					return
				}
				delivery.Ack(false)
			}(d)
		}
	}
}

func (c *Consumer) Close() {
	c.channel.Close()
	c.conn.Close()
}

func connectGRPCWithRetry(target string, maxRetries int) (*grpc.ClientConn, error) {
	var conn *grpc.ClientConn
	var err error

	for i := 0; i < maxRetries; i++ {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		conn, err = grpc.DialContext(ctx, target, grpc.WithTransportCredentials(insecure.NewCredentials()), grpc.WithBlock())
		cancel()
		if err == nil {
			return conn, nil
		}
		log.Printf("gRPC no disponible en %s, reintentando en 3s... (%d/%d)", target, i+1, maxRetries)
		time.Sleep(3 * time.Second)
	}

	return nil, err
}

func atacarAkatsuki(ctx context.Context, clienteAtaque pb1.SendAtaqueClient, ninja *NinjaTeam, reader *bufio.Reader) {
	fmt.Print("Ingrese el nombre del Akatsuki a atacar: ")
	nombreAkatsuki, _ := reader.ReadString('\n')
	nombreAkatsuki = strings.TrimSpace(nombreAkatsuki)

	stream, err := clienteAtaque.Combate(ctx)
	if err != nil {
		log.Printf("Error al iniciar combate: %v", err)
		return
	}

	hpOriginalNinja := ninja.hp
	fmt.Printf("\n⚔️  Comienza Combate %s vs %s\n", ninja.name, nombreAkatsuki)
	time.Sleep(1 * time.Second)
	err = stream.Send(&pb1.CombateRequest{
		NombreAkatsuki:  nombreAkatsuki,
		NombreNinjateam: ninja.name,
		Ataque:          int32(ninja.attack),
	})
	if err != nil {
		log.Printf("Error enviando ataque inicial: %v", err)
		return
	}

	for {
		resp, err := stream.Recv()
		if err != nil {
			log.Printf("Combate terminado: %v", err)
			break
		}

		ninja.hp -= int(resp.GetAtaqueAkatsuki())
		switch resp.GetResultado() {
		case "en_curso":
			if ninja.hp <= 0 {
				fmt.Printf("💀 %s fue derrotado. Combate finalizado\n", ninja.name)
				ninja.hp = hpOriginalNinja
				stream.Send(&pb1.CombateRequest{
					NombreAkatsuki:  nombreAkatsuki,
					NombreNinjateam: ninja.name,
					Ataque:          -1,
				})
				stream.CloseSend()
				return
			}
			time.Sleep(1 * time.Second)
		case "victoria":
			fmt.Printf("🏆 %s fue capturado. Combate finalizado\n", nombreAkatsuki)
			capturados = append(capturados, AkatsukiCapturado{nombre: nombreAkatsuki})
			stream.CloseSend()
			return
		case "escapo":
			fmt.Println("💨 Combate finalizado")
			stream.CloseSend()
			return
		default:
			if ninja.hp <= 0 {
				fmt.Printf("💀 %s fue derrotado. Combate finalizado\n", ninja.name)
				ninja.hp = hpOriginalNinja
				stream.Send(&pb1.CombateRequest{
					NombreAkatsuki:  nombreAkatsuki,
					NombreNinjateam: ninja.name,
					Ataque:          -1,
				})
				stream.CloseSend()
				return
			}
		}

		time.Sleep(1 * time.Second)
		err = stream.Send(&pb1.CombateRequest{
			NombreAkatsuki:  nombreAkatsuki,
			NombreNinjateam: ninja.name,
			Ataque:          int32(ninja.attack),
		})
		if err != nil {
			log.Printf("Error enviando ataque: %v", err)
			return
		}
	}
}

func mostrarCapturados() {
	if len(capturados) == 0 {
		fmt.Println("No hay akatsukis capturados aún")
		return
	}
	fmt.Println("\n=== Akatsukis Capturados ===")
	for i, a := range capturados {
		cobrado := ""
		if a.bounty > 0 {
			cobrado = fmt.Sprintf("| Recompensa cobrada: %d ryos", a.bounty)
		}
		fmt.Printf("  %d. %s %s\n", i+1, a.nombre, cobrado)
	}
	fmt.Println("============================")
}

func readInt(reader *bufio.Reader, prompt string) int {
	for {
		fmt.Print(prompt)
		text, _ := reader.ReadString('\n')
		text = strings.TrimSpace(text)

		value, err := strconv.Atoi(text)
		if err == nil {
			return value
		}

		fmt.Println("Entrada invalida, ingrese un numero entero")
	}
}

func main() {
	hokageAddr := os.Getenv("HOKAGE_ADDR")
	if hokageAddr == "" {
		hokageAddr = "hokage:50052"
	}

	akatsukiAddr := os.Getenv("AKATSUKI_ADDR")
	if akatsukiAddr == "" {
		akatsukiAddr = "akatsuki:50051"
	}

	connHokage, err := connectGRPCWithRetry(hokageAddr, 20)
	if err != nil {
		log.Fatalf("failed to connect to Hokage gRPC server: %v", err)
	}
	defer connHokage.Close()
	client := pb.NewHokageServiceClient(connHokage)

	connAkatsuki, err := connectGRPCWithRetry(akatsukiAddr, 20)
	if err != nil {
		log.Fatalf("failed to connect to Akatsuki gRPC server: %v", err)
	}
	defer connAkatsuki.Close()
	clienteAtaque := pb1.NewSendAtaqueClient(connAkatsuki)

	amqpUrl := os.Getenv("RABBITMQ_URL")
	if amqpUrl == "" {
		amqpUrl = "amqp://guest:guest@localhost:5672/"
	}

	var nombre string
	var attack int
	var hp int
	var saldo int
	reader := bufio.NewReader(os.Stdin)

	defaultName := os.Getenv("NINJA_NAME")
	if defaultName != "" {
		nombre = defaultName
		fmt.Printf("Nombre de ninja por variable de entorno: %s\n", nombre)
	} else {
		for {
			fmt.Print("Ingrese el nombre del ninja: ")
			input, _ := reader.ReadString('\n')
			input = strings.TrimSpace(input)
			if input != "" {
				nombre = input
				break
			}
			fmt.Println("Entrada invalida, intente de nuevo")
		}
	}

	attack = readInt(reader, "Ingrese el ataque del ninja: ")
	hp = readInt(reader, "Ingrese el HP del ninja: ")
	saldo = readInt(reader, "Ingrese el saldo del ninja: ")
	ninja := createNinjaTeam(nombre, attack, hp, saldo)
	fmt.Printf("Ninja creado: %+v\n", ninja)

	consumer, err := connectConsumerWithRetry(amqpUrl, 5)
	if err != nil {
		log.Fatalf("Error al conectar con RabbitMQ: %v", err)
	}
	defer consumer.Close()

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	msgCh := make(chan string, 10)

	go func() {
		err := consumer.Listen(ctx, "ninja_queue", func(ctx context.Context, body []byte) error {
			msgCh <- string(body)
			return nil
		})
		if err != nil {
			log.Printf("Error en el listener de Ninja: %v", err)
		}
	}()

	fmt.Printf("1- Pedir Lista\n2- Atacar Akatsuki\n3- Mostrar capturados\n4- Reclamar recompensa\n5- Ver estadísticas\n6- Salir\n")
	for {
		for {
			select {
			case msg := <-msgCh:
				fmt.Printf("\n[ANBU] %s\n", msg)
			default:
				goto readInput
			}
		}
	readInput:
		fmt.Print("Ingrese una opción: ")
		input, _ := reader.ReadString('\n')
		input = strings.TrimSpace(input)

		for {
			select {
			case msg := <-msgCh:
				fmt.Printf("\n[ANBU] %s\n", msg)
			default:
				goto processInput
			}
		}
	processInput:
		var opcion int
		_, err := fmt.Sscan(input, &opcion)
		if err != nil {
			fmt.Println("Entrada inválida, intente de nuevo")
			continue
		}

		switch opcion {
		case 1:
			fmt.Println("Solicitando lista...")
			resp, err := client.GetLista(ctx, &pb.ListaRequest{})
			if err != nil {
				log.Printf("Error al obtener lista: %v", err)
			} else {
				fmt.Printf("Lista de Akatsukis:\n%s\n", resp.GetLista())
			}
		case 2:
			atacarAkatsuki(ctx, clienteAtaque, &ninja, reader)
		case 3:
			mostrarCapturados()
		case 4:
			mostrarCapturados()
			if len(capturados) == 0 {
				continue
			}
			fmt.Print("Ingrese el nombre del Akatsuki por el que quiere cobrar recompensa: ")
			nombreAkatsuki, _ := reader.ReadString('\n')
			nombreAkatsuki = strings.TrimSpace(nombreAkatsuki)

			encontrado := false
			for i, a := range capturados {
				if a.nombre == nombreAkatsuki {
					encontrado = true
					if a.bounty > 0 {
						fmt.Printf("Ya cobraste la recompensa de %s: %d ryos\n", a.nombre, a.bounty)
						break
					}
					resp, err := client.GetRecompensa(ctx, &pb.RecompensaRequest{Nombre: nombreAkatsuki})
					if err != nil {
						log.Printf("Error al solicitar recompensa: %v", err)
						break
					}
					fmt.Printf("💰 Recompensa por %s: %d ryos\n", resp.GetNombre(), resp.GetBounty())
					capturados[i].bounty = int(resp.GetBounty())
					ninja.saldo += int(resp.GetBounty())
					break
				}
			}
			if !encontrado {
				fmt.Printf("%s no está en tu lista de capturados\n", nombreAkatsuki)
			}
		case 5:
			fmt.Printf("=== Estadísticas de %s ===\n", ninja.name)
			fmt.Printf("HP: %d\n", ninja.hp)
			fmt.Printf("Ataque: %d\n", ninja.attack)
			fmt.Printf("Saldo: %d ryos\n", ninja.saldo)
			fmt.Printf("Akatsukis capturados: %d\n", len(capturados))
			fmt.Println("==========================")
		case 6:
			fmt.Println("Saliendo...")
			return
		default:
			fmt.Println("Opción no válida")
		}
	}
}
