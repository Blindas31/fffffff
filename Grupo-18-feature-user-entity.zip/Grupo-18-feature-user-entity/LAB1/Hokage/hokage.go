package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net"
	"os"
	"sync"
	"time"

	pb "hokage/proto/grpc_ninja/proto"

	amqp "github.com/rabbitmq/amqp091-go"
	"google.golang.org/grpc"
)

// ======================== Tipos ======================== //

// Debe coincidir con lo que ANBU publica en anbu.intel
type server struct {
	pb.UnimplementedHokageServiceServer
	store *AkatsukiStore
}
type AkatsukiEvent struct {
	ID        string    `json:"id"`
	EventType string    `json:"event_type"`
	Nombre    string    `json:"nombre"`
	HP        int       `json:"hp"`
	ATK       int       `json:"atk"`
	Status    string    `json:"status"`
	Timestamp time.Time `json:"timestamp"`
}

type AkatsukiConBounty struct {
	AkatsukiEvent
	Bounty int `json:"bounty"`
}

type HandlerFunc func(ctx context.Context, body []byte) error

// AkatsukiStore guarda en memoria hasta que esté listo el gRPC
type AkatsukiStore struct {
	mu   sync.Mutex
	data map[string]*AkatsukiConBounty
}

func NewAkatsukiStore() *AkatsukiStore {
	return &AkatsukiStore{
		data: make(map[string]*AkatsukiConBounty),
	}
}

func (s *AkatsukiStore) Save(a *AkatsukiConBounty) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.data[a.Nombre] = a
	log.Printf("[Hokage] Akatsuki registrado: %s | Bounty: %d", a.Nombre, a.Bounty)
}

// ======================== Bounty ======================== //

func BountyAssign(event *AkatsukiEvent) *AkatsukiConBounty {
	var baseBounty int
	switch {
	case event.ATK >= 130:
		baseBounty = 10_000_000
	case event.ATK >= 90:
		baseBounty = 5_000_000
	case event.ATK >= 70:
		baseBounty = 1_000_000
	default:
		log.Printf("[Hokage] ATK bajo para %s: %d, usando base mínima", event.Nombre, event.ATK)
		baseBounty = 500_000
	}

	return &AkatsukiConBounty{
		AkatsukiEvent: *event,
		Bounty:        baseBounty + (event.HP * 1000),
	}
}

// ======================== Consumer ======================== //

type Consumer struct {
	conn    *amqp.Connection
	channel *amqp.Channel
}

func connectConsumerWithRetry(amqpUrl string, maxRetries int) (*Consumer, error) {
	var err error
	for i := 0; i < maxRetries; i++ {
		c, e := createConsumer(amqpUrl)
		if e == nil {
			return c, nil
		}
		err = e
		log.Printf("RabbitMQ no disponible, reintentando consumer en 5s... (%d/%d)", i+1, maxRetries)
		time.Sleep(5 * time.Second)
	}
	return nil, err
}

func createConsumer(amqpUrl string) (*Consumer, error) {
	conn, err := amqp.Dial(amqpUrl)
	if err != nil {
		return nil, fmt.Errorf("failed to connect to RabbitMQ: %v", err)
	}
	ch, err := conn.Channel()
	if err != nil {
		conn.Close()
		return nil, fmt.Errorf("failed to create channel: %v", err)
	}
	if err := ch.Qos(1, 0, false); err != nil {
		conn.Close()
		return nil, fmt.Errorf("failed to set QoS: %v", err)
	}
	return &Consumer{conn: conn, channel: ch}, nil
}

func (c *Consumer) Listen(ctx context.Context, queueName string, handler HandlerFunc) error {
	_, err := c.channel.QueueDeclare(queueName, true, false, false, false, nil)
	if err != nil {
		return fmt.Errorf("failed to declare queue: %v", err)
	}

	msgs, err := c.channel.Consume(queueName, "", false, false, false, false, nil)
	if err != nil {
		return fmt.Errorf("failed to register consumer: %v", err)
	}

	log.Printf("[Hokage] Escuchando en la cola: %s", queueName)

	var wg sync.WaitGroup
	for {
		select {
		case <-ctx.Done():
			wg.Wait()
			return nil
		case d, ok := <-msgs:
			if !ok {
				wg.Wait()
				return fmt.Errorf("channel closed")
			}
			wg.Add(1)
			go func(delivery amqp.Delivery) {
				defer wg.Done()
				if err := handler(ctx, delivery.Body); err != nil {
					log.Printf("[Hokage] Error procesando mensaje: %v", err)
					delivery.Nack(false, false)
					return
				}
				delivery.Ack(false)
			}(d)
		}
	}
}

func (c *Consumer) Close() {
	c.channel.Close()
	c.conn.Close()
}

func (s *server) GetLista(ctx context.Context, req *pb.ListaRequest) (*pb.ListaResponse, error) {
	s.store.mu.Lock()
	defer s.store.mu.Unlock()

	if len(s.store.data) == 0 {
		return &pb.ListaResponse{Lista: "No hay akatsukis registrados"}, nil
	}

	var lista string
	for _, a := range s.store.data {
		lista += fmt.Sprintf("%s: HP %d, ATK %d, Bounty %d, Status %s\n",
			a.Nombre, a.HP, a.ATK, a.Bounty, a.Status)
	}

	return &pb.ListaResponse{Lista: lista}, nil
}

func (s *server) GetRecompensa(ctx context.Context, req *pb.RecompensaRequest) (*pb.RecompensaResponse, error) {
	s.store.mu.Lock()
	defer s.store.mu.Unlock()

	a, existe := s.store.data[req.Nombre]
	if !existe {
		return nil, fmt.Errorf("akatsuki %s no encontrado", req.Nombre)
	}

	return &pb.RecompensaResponse{
		Nombre: a.Nombre,
		Bounty: int32(a.Bounty),
	}, nil
}

// ======================== Main ======================== //

func main() {
	// ======================== gRPC ======================== //
	lis, err := net.Listen("tcp", ":50052")
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}

	store := NewAkatsukiStore()

	grpcHokage := grpc.NewServer()
	pb.RegisterHokageServiceServer(grpcHokage, &server{store: store})
	log.Printf("[Hokage] gRPC escuchando en :50052")

	go func() {
		if err := grpcHokage.Serve(lis); err != nil {
			log.Fatalf("failed to serve: %v", err)
		}
	}()

	// ======================== RabbitMQ ======================== //
	amqpUrl := os.Getenv("RABBITMQ_URL")
	if amqpUrl == "" {
		amqpUrl = "amqp://guest:guest@localhost:5672/"
	}

	hokageHandler := func(ctx context.Context, body []byte) error {
		var event AkatsukiEvent
		if err := json.Unmarshal(body, &event); err != nil {
			return fmt.Errorf("failed to unmarshal event: %v", err)
		}
		log.Printf("[Hokage] Mensaje recibido: %s | HP: %d | ATK: %d | Status: %s",
			event.Nombre, event.HP, event.ATK, event.Status)

		if event.EventType == "akatsuki.appeared" {
			akatsukiConBounty := BountyAssign(&event)
			log.Printf("[Hokage] Bounty asignada a %s: %d ryos", akatsukiConBounty.Nombre, akatsukiConBounty.Bounty)
			store.Save(akatsukiConBounty)
		} else {
			store.mu.Lock()
			defer store.mu.Unlock()
			if a, existe := store.data[event.Nombre]; existe {
				a.HP = event.HP
				a.Status = event.Status
				store.data[event.Nombre] = a
				log.Printf("[Hokage] Akatsuki actualizado: %s | HP: %d | Status: %s",
					a.Nombre, a.HP, a.Status)
			}
		}
		return nil
	}

	consumer, err := connectConsumerWithRetry(amqpUrl, 5)
	if err != nil {
		log.Fatalf("error conectando consumer a RabbitMQ: %v", err)
	}
	defer consumer.Close()

	ctx := context.Background()
	if err := consumer.Listen(ctx, "anbu.intel", hokageHandler); err != nil {
		log.Fatalf("error escuchando en RabbitMQ: %v", err)
	}
}
