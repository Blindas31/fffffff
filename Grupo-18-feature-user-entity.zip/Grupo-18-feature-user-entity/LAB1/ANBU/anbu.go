package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"sync"
	"time"

	"github.com/google/uuid"
	amqp "github.com/rabbitmq/amqp091-go"
)
//Estructuras necesarias
type Consumer struct {
	conn    *amqp.Connection
	channel *amqp.Channel
}
type ReportarStatus struct {
	Nombre string `json:"nombre"`
	Status string `json:"status"`
}

type Publisher struct {
	conn    *amqp.Connection
	channel *amqp.Channel
}

type HandlerFunc func(ctx context.Context, body []byte) error

type AkatsukiEvent struct {
	ID        string    `json:"id"`
	EventType string    `json:"event_type"`
	Nombre    string    `json:"nombre"`
	HP        int       `json:"hp"`
	ATK       int       `json:"atk"`
	Status    string    `json:"status"`
	Timestamp time.Time `json:"timestamp"`
}
//Colas de RabbitMQ y variables
const (
	QueueAppeared = "akatsuki.appeared"
	QueueUpdated  = "akatsuki.updated"
	QueueIntel    = "anbu.intel"
	QueueNinja    = "ninja_queue"
)

var (
	akatsukisDetectados = map[string]AkatsukiEvent{}
	mu                  sync.RWMutex
)

// ======================== Consumer ======================== //
func connectConsumerWithRetry(amqpUrl string, maxRetries int) (*Consumer, error) {
	var consumer *Consumer
	var err error
	for i := 0; i < maxRetries; i++ {
		consumer, err = createConsumer(amqpUrl)
		if err == nil {
			return consumer, nil
		}
		log.Printf("RabbitMQ no disponible, reintentando consumer en 5s... (%d/%d)", i+1, maxRetries)
		time.Sleep(5 * time.Second)
	}
	return nil, err
}
func createConsumer(amqpUrl string) (*Consumer, error) {
	conn, err := amqp.Dial(amqpUrl)
	if err != nil {
		return nil, fmt.Errorf("failed to connect to RabbitMQ: %v", err)
	}
	ch, err := conn.Channel()
	if err != nil {
		conn.Close()
		return nil, fmt.Errorf("failed to create channel: %v", err)
	}
	if err := ch.Qos(1, 0, false); err != nil {
		conn.Close()
		return nil, fmt.Errorf("failed to set QoS: %v", err)
	}
	return &Consumer{conn: conn, channel: ch}, nil
}

func (c *Consumer) Listen(ctx context.Context, queueName string, handler HandlerFunc) error {
	_, err := c.channel.QueueDeclare(
		queueName,
		true,
		false,
		false,
		false,
		nil,
	)
	if err != nil {
		return fmt.Errorf("failed to declare queue: %v", err)
	}

	msgs, err := c.channel.Consume(
		queueName,
		"",
		false,
		false,
		false,
		false,
		nil,
	)
	if err != nil {
		return fmt.Errorf("failed to register consumer: %v", err)
	}

	log.Printf("ANBU escuchando en la cola: %s", queueName)

	for {
		select {
		case <-ctx.Done():
			return nil
		case d, ok := <-msgs:
			if !ok {
				return fmt.Errorf("channel closed")
			}
			go func(delivery amqp.Delivery) {
				if err := handler(ctx, delivery.Body); err != nil {
					log.Printf("error procesando mensaje: %v", err)
					delivery.Nack(false, false)
					return
				}
				delivery.Ack(false)
			}(d)
		}
	}
}

func (c *Consumer) Close() {
	c.channel.Close()
	c.conn.Close()
}

// ======================== Publisher ======================== //

func connectPublisherWithRetry(amqpUrl string, maxRetries int) (*Publisher, error) {
	var publisher *Publisher
	var err error
	for i := 0; i < maxRetries; i++ {
		publisher, err = connectionCreate(amqpUrl)
		if err == nil {
			return publisher, nil
		}
		log.Printf("RabbitMQ no disponible, reintentando publisher en 5s... (%d/%d)", i+1, maxRetries)
		time.Sleep(5 * time.Second)
	}
	return nil, err
}
func connectionCreate(amqpUrl string) (*Publisher, error) {
	conn, err := amqp.Dial(amqpUrl)
	if err != nil {
		return nil, err
	}
	ch, err := conn.Channel()
	if err != nil {
		conn.Close()
		return nil, err
	}
	return &Publisher{conn: conn, channel: ch}, nil
}

func (p *Publisher) Publish(queueName string, body interface{}) error {
	_, err := p.channel.QueueDeclare(
		queueName,
		true,
		false,
		false,
		false,
		nil,
	)
	if err != nil {
		return fmt.Errorf("failed to declare queue: %v", err)
	}

	data, err := json.Marshal(body)
	if err != nil {
		return fmt.Errorf("failed to marshal body: %v", err)
	}

	return p.channel.PublishWithContext(
		context.Background(),
		"",
		queueName,
		false,
		false,
		amqp.Publishing{
			ContentType:  "application/json",
			DeliveryMode: amqp.Persistent,
			MessageId:    uuid.New().String(),
			Timestamp:    time.Now(),
			Body:         data,
		},
	)
}

func (p *Publisher) Close() {
	p.channel.Close()
	p.conn.Close()
}

// ======================= Lógica ANBU ======================= //

// Anbu -> Hokage
func actualizarListaAkatsuki(publisher *Publisher, event AkatsukiEvent) {
	mu.Lock()
	akatsukisDetectados[event.Nombre] = event
	mu.Unlock()

	log.Printf("[ANBU] %s → %s | HP: %d | ATK: %d | Status: %s",
		event.EventType, event.Nombre, event.HP, event.ATK, event.Status)

	intel := AkatsukiEvent{
		ID:        uuid.New().String(),
		EventType: event.EventType,
		Nombre:    event.Nombre,
		HP:        event.HP,
		ATK:       event.ATK,
		Status:    event.Status,
		Timestamp: time.Now(),
	}

	if err := publisher.Publish(QueueIntel, intel); err != nil {
		log.Printf("error publicando en %s: %v", QueueIntel, err)
	}
} 
// Anbu -> Ninja
func avisarNinja(publisher *Publisher, event AkatsukiEvent) error {
	if event.Status != "En Combate" {
		return nil
	}
	msg := ReportarStatus{
		Nombre: event.Nombre,
		Status: event.Status,
	}
	return publisher.Publish(QueueNinja, msg)
}
func buildHandler(publisher *Publisher) HandlerFunc {
	return func(ctx context.Context, body []byte) error {
		var event AkatsukiEvent
		if err := json.Unmarshal(body, &event); err != nil {
			return fmt.Errorf("error deserializando evento: %v", err)
		}

		go actualizarListaAkatsuki(publisher, event)
		go avisarNinja(publisher, event)

		return nil
	}
}
// Akatsuki -> ANBU
func showDetectados() {
	mu.RLock()
	defer mu.RUnlock()

	fmt.Println("\n[ANBU] Akatsukis detectados:")
	for nombre, event := range akatsukisDetectados {
		fmt.Printf("  → %s | Status: %s | HP: %d | ATK: %d\n",
			nombre, event.Status, event.HP, event.ATK)
	}
}

func main() {
	amqpUrl := os.Getenv("RABBITMQ_URL")
	if amqpUrl == "" {
		amqpUrl = "amqp://guest:guest@localhost:5672/"
	}
	publisher, err := connectPublisherWithRetry(amqpUrl, 5)
	if err != nil {
		log.Fatalf("error conectando publisher a RabbitMQ: %v", err)
	}
	defer publisher.Close()

	consumer, err := connectConsumerWithRetry(amqpUrl, 5)
	if err != nil {
		log.Fatalf("error conectando consumer a RabbitMQ: %v", err)
	}
	defer consumer.Close()

	consumer2, err := connectConsumerWithRetry(amqpUrl, 5)
	if err != nil {
		log.Fatalf("error conectando consumer2 a RabbitMQ: %v", err)
	}
	defer consumer2.Close()

	ctx := context.Background()
	handler := buildHandler(publisher)

	go func() {
		if err := consumer.Listen(ctx, QueueAppeared, handler); err != nil {
			log.Printf("error en cola %s: %v", QueueAppeared, err)
		}
	}()

	go func() {
		if err := consumer2.Listen(ctx, QueueUpdated, handler); err != nil {
			log.Printf("error en cola %s: %v", QueueUpdated, err)
		}
	}()

	log.Println("[ANBU] Servicio activo, esperando mensajes...")
	select {}
}
