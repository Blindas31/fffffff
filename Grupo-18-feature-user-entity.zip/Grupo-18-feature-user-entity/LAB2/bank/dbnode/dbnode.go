package main

import (
	"context"
	pbDatabase "dbnode/proto/grpc_database/proto"
	pbRegister "dbnode/proto/grpc_register/proto"
	"flag"
	"log"
	"math/rand"
	"net"
	"strings"
	"sync"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

type DBServerNode struct {
	pbDatabase.UnimplementedDatabaseServiceServer
	mutex          sync.RWMutex
	nodeID         string
	exitoEscritura int
	exitoLectura   int

	eventosMap map[string]string
	comprasMap map[string]string
	ticketsMap map[string]string
}

func NewDBServerNode(nodeID string, exitoEscritura int, exitoLectura int) *DBServerNode {
	return &DBServerNode{
		nodeID:         nodeID,
		exitoEscritura: exitoEscritura,
		exitoLectura:   exitoLectura,
		eventosMap:     make(map[string]string),
		comprasMap:     make(map[string]string),
		ticketsMap:     make(map[string]string),
	}
}

// =====================================================
// ESCRITURAS
// =====================================================

func (s *DBServerNode) WriteEvento(ctx context.Context, req *pbDatabase.WriteRequest) (*pbDatabase.WriteResponse, error) {
	if rand.Intn(100) >= s.exitoEscritura {
		log.Printf("Nodo %s: Escritura de evento %s fallida (simulación)", s.nodeID, req.GetId())
		return &pbDatabase.WriteResponse{Success: false, Message: "Escritura fallida"}, nil
	}
	s.mutex.Lock()
	defer s.mutex.Unlock()

	if req.GetId() == "" || req.GetContent() == "" {
		return &pbDatabase.WriteResponse{Success: false, Message: "ID o contenido vacío"}, nil
	}
	s.eventosMap[req.GetId()] = req.GetContent()
	log.Printf("Nodo %s: Evento %s escrito exitosamente", s.nodeID, req.GetId())
	return &pbDatabase.WriteResponse{Success: true, Message: "Evento escrito exitosamente"}, nil
}

func (s *DBServerNode) WriteCompra(ctx context.Context, req *pbDatabase.WriteRequest) (*pbDatabase.WriteResponse, error) {
	if rand.Intn(100) >= s.exitoEscritura {
		log.Printf("Nodo %s: Escritura de compra %s fallida (simulación)", s.nodeID, req.GetId())
		return &pbDatabase.WriteResponse{Success: false, Message: "Escritura fallida"}, nil
	}
	s.mutex.Lock()
	defer s.mutex.Unlock()

	if req.GetId() == "" || req.GetContent() == "" {
		return &pbDatabase.WriteResponse{Success: false, Message: "ID o contenido vacío"}, nil
	}
	s.comprasMap[req.GetId()] = req.GetContent()
	log.Printf("Nodo %s: Compra %s escrita exitosamente", s.nodeID, req.GetId())
	return &pbDatabase.WriteResponse{Success: true, Message: "Compra escrita exitosamente"}, nil
}

func (s *DBServerNode) WriteTicket(ctx context.Context, req *pbDatabase.WriteRequest) (*pbDatabase.WriteResponse, error) {
	if rand.Intn(100) >= s.exitoEscritura {
		log.Printf("Nodo %s: Escritura de ticket %s fallida (simulación)", s.nodeID, req.GetId())
		return &pbDatabase.WriteResponse{Success: false, Message: "Escritura fallida"}, nil
	}
	s.mutex.Lock()
	defer s.mutex.Unlock()

	if req.GetId() == "" || req.GetContent() == "" {
		return &pbDatabase.WriteResponse{Success: false, Message: "ID o contenido vacío"}, nil
	}
	s.ticketsMap[req.GetId()] = req.GetContent()
	log.Printf("Nodo %s: Ticket %s escrito exitosamente", s.nodeID, req.GetId())
	return &pbDatabase.WriteResponse{Success: true, Message: "Ticket escrito exitosamente"}, nil
}

// =====================================================
// LECTURAS
// =====================================================

func (s *DBServerNode) ReadEvento(ctx context.Context, req *pbDatabase.ReadRequest) (*pbDatabase.ReadResponse, error) {
	if rand.Intn(100) >= s.exitoLectura {
		log.Printf("Nodo %s: Lectura de evento fallida (simulación)", s.nodeID)
		return &pbDatabase.ReadResponse{Success: false}, nil
	}
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	// ID específico → devolver solo ese
	if req.GetId() != "" {
		content, exists := s.eventosMap[req.GetId()]
		if !exists {
			return &pbDatabase.ReadResponse{Success: false}, nil
		}
		return &pbDatabase.ReadResponse{Success: true, Contents: []string{content}}, nil
	}

	// Sin ID → devolver todos
	todos := make([]string, 0, len(s.eventosMap))
	for _, content := range s.eventosMap {
		todos = append(todos, content)
	}
	return &pbDatabase.ReadResponse{Success: true, Contents: todos}, nil
}

func (s *DBServerNode) ReadCompra(ctx context.Context, req *pbDatabase.ReadRequest) (*pbDatabase.ReadResponse, error) {
	if rand.Intn(100) >= s.exitoLectura {
		log.Printf("Nodo %s: Lectura de compra fallida (simulación)", s.nodeID)
		return &pbDatabase.ReadResponse{Success: false}, nil
	}
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	if req.GetId() != "" {
		content, exists := s.comprasMap[req.GetId()]
		if !exists {
			return &pbDatabase.ReadResponse{Success: false}, nil
		}
		return &pbDatabase.ReadResponse{Success: true, Contents: []string{content}}, nil
	}

	todos := make([]string, 0, len(s.comprasMap))
	for _, content := range s.comprasMap {
		todos = append(todos, content)
	}
	return &pbDatabase.ReadResponse{Success: true, Contents: todos}, nil
}

func (s *DBServerNode) ReadTicket(ctx context.Context, req *pbDatabase.ReadRequest) (*pbDatabase.ReadResponse, error) {
	if rand.Intn(100) >= s.exitoLectura {
		log.Printf("Nodo %s: Lectura de ticket fallida (simulación)", s.nodeID)
		return &pbDatabase.ReadResponse{Success: false}, nil
	}
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	if req.GetId() != "" {
		content, exists := s.ticketsMap[req.GetId()]
		if !exists {
			return &pbDatabase.ReadResponse{Success: false}, nil
		}
		return &pbDatabase.ReadResponse{Success: true, Contents: []string{content}}, nil
	}

	todos := make([]string, 0, len(s.ticketsMap))
	for _, content := range s.ticketsMap {
		todos = append(todos, content)
	}
	return &pbDatabase.ReadResponse{Success: true, Contents: todos}, nil
}

// =====================================================
// SINCRONIZACIÓN
// =====================================================

// GetSync expone todos los datos del nodo a sus pares
func (s *DBServerNode) GetSync(ctx context.Context, req *pbDatabase.SyncRequest) (*pbDatabase.SyncResponse, error) {
	s.mutex.RLock()
	defer s.mutex.RUnlock()

	var eventos []*pbDatabase.SyncEntry
	for id, content := range s.eventosMap {
		eventos = append(eventos, &pbDatabase.SyncEntry{Id: id, Content: content})
	}
	var compras []*pbDatabase.SyncEntry
	for id, content := range s.comprasMap {
		compras = append(compras, &pbDatabase.SyncEntry{Id: id, Content: content})
	}
	var tickets []*pbDatabase.SyncEntry
	for id, content := range s.ticketsMap {
		tickets = append(tickets, &pbDatabase.SyncEntry{Id: id, Content: content})
	}

	log.Printf("Nodo %s: GetSync - %d eventos, %d compras, %d tickets",
		s.nodeID, len(eventos), len(compras), len(tickets))

	return &pbDatabase.SyncResponse{
		Success: true,
		Eventos: eventos,
		Compras: compras,
		Tickets: tickets,
	}, nil
}

// SyncData pide datos a los pares y aplica lo que le falta
func (s *DBServerNode) SyncData(peerAddrs []string) {
	for _, addr := range peerAddrs {
		conn, err := grpc.Dial(addr, grpc.WithTransportCredentials(insecure.NewCredentials()))
		if err != nil {
			log.Printf("Nodo %s: Error al conectar con par %s: %v", s.nodeID, addr, err)
			continue
		}
		peerClient := pbDatabase.NewDatabaseServiceClient(conn)
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		resp, err := peerClient.GetSync(ctx, &pbDatabase.SyncRequest{})
		cancel()
		conn.Close()

		if err != nil || !resp.GetSuccess() {
			log.Printf("Nodo %s: Error al sincronizar con par %s", s.nodeID, addr)
			continue
		}

		s.mutex.Lock()
		nuevosEventos, nuevasCompras, nuevosTickets := 0, 0, 0

		for _, entry := range resp.GetEventos() {
			if _, exists := s.eventosMap[entry.GetId()]; !exists {
				s.eventosMap[entry.GetId()] = entry.GetContent()
				nuevosEventos++
			}
		}
		for _, entry := range resp.GetCompras() {
			if _, exists := s.comprasMap[entry.GetId()]; !exists {
				s.comprasMap[entry.GetId()] = entry.GetContent()
				nuevasCompras++
			}
		}
		for _, entry := range resp.GetTickets() {
			if _, exists := s.ticketsMap[entry.GetId()]; !exists {
				s.ticketsMap[entry.GetId()] = entry.GetContent()
				nuevosTickets++
			}
		}
		s.mutex.Unlock()

		log.Printf("Nodo %s: Sync con %s - +%d eventos, +%d compras, +%d tickets",
			s.nodeID, addr, nuevosEventos, nuevasCompras, nuevosTickets)
	}
}

// =====================================================
// REGISTRO EN EL BROKER
// =====================================================

func RegistroBroker(brokerAddr string, nodeID string, myAddr string) {
	for {
		conn, err := grpc.Dial(brokerAddr, grpc.WithTransportCredentials(insecure.NewCredentials()))
		if err != nil {
			log.Printf("Nodo %s: Error al conectar con broker: %v, reintento en 3s", nodeID, err)
			time.Sleep(3 * time.Second)
			continue
		}
		registerClient := pbRegister.NewRegistrationServiceClient(conn)
		resp, err := registerClient.RegisterDB(
			context.Background(),
			&pbRegister.DbRegisterRequest{
				Nodeid: nodeID,
				Adress: myAddr,
			},
		)
		conn.Close()

		if err != nil {
			log.Printf("Nodo %s: Error al registrarse en broker: %v, reintento en 3s", nodeID, err)
			time.Sleep(3 * time.Second)
			continue
		}
		if !resp.GetSuccess() {
			log.Printf("Nodo %s: Registro rechazado: %s", nodeID, resp.GetMessage())
		} else {
			log.Printf("Nodo %s: Registrado en broker exitosamente", nodeID)
		}
		return
	}
}

// =====================================================
// MAIN
// =====================================================

func main() {
	nodeID := flag.String("id", "DB1", "ID del nodo (DB1, DB2, DB3)")
	port := flag.String("port", "50052", "Puerto de este nodo")
	addr := flag.String("addr", "localhost", "Dirección de este nodo")
	brokerAddr := flag.String("broker", "localhost:50051", "Dirección del broker")
	peersFlag := flag.String("peers", "", "Direcciones de los otros nodos. Ej: localhost:50053,localhost:50054")
	exitoEscritura := flag.Int("exito-escritura", 100, "% éxito en escrituras (0-100)")
	exitoLectura := flag.Int("exito-lectura", 100, "% éxito en lecturas (0-100)")
	syncInterval := flag.Int("sync-interval", 30, "Intervalo de sincronización en segundos")
	flag.Parse()

	rand.Seed(time.Now().UnixNano())

	var peerAddrs []string
	if *peersFlag != "" {
		peerAddrs = strings.Split(*peersFlag, ",")
	}

	myAddr := *addr + ":" + *port

	log.Printf("[%s] Iniciando nodo DB en %s (escritura: %d%%, lectura: %d%%)",
		*nodeID, myAddr, *exitoEscritura, *exitoLectura)

	lis, err := net.Listen("tcp", ":"+*port)
	if err != nil {
		log.Fatalf("[%s] No se pudo escuchar en puerto %s: %v", *nodeID, *port, err)
	}

	grpcServer := grpc.NewServer()
	dbServer := NewDBServerNode(*nodeID, *exitoEscritura, *exitoLectura)
	pbDatabase.RegisterDatabaseServiceServer(grpcServer, dbServer)

	go RegistroBroker(*brokerAddr, *nodeID, myAddr)

	if len(peerAddrs) > 0 {
		go func() {
			time.Sleep(10 * time.Second)
			ticker := time.NewTicker(time.Duration(*syncInterval) * time.Second)
			defer ticker.Stop()
			for range ticker.C {
				log.Printf("[%s] Sincronizando con pares...", *nodeID)
				dbServer.SyncData(peerAddrs)
			}
		}()
	}

	log.Printf("[%s] Escuchando en :%s", *nodeID, *port)
	if err := grpcServer.Serve(lis); err != nil {
		log.Fatalf("[%s] Error en servidor: %v", *nodeID, err)
	}
}
