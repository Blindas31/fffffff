# Contexto detallado Laboratorio 2 - Sistemas Distribuidos

## Identificación del laboratorio

- Universidad: Universidad Técnica Federico Santa María.
- Asignatura: Sistemas Distribuidos.
- Laboratorio: Laboratorio 2.
- Nombre del sistema: DiscoPass.
- Profesor: Jorge Díaz.
- Ayudantes de laboratorio: Felipe Marchant V. y Nelson Sepúlveda V.
- Tecnologías obligatorias:
  - Go.
  - gRPC.
  - Protocol Buffers.
  - Docker.
- Fecha de entrega indicada: 10 de junio a las 23:59 hrs.

## Objetivo general

El laboratorio pide implementar un sistema distribuido de venta, compra y validación de entradas para discotecas. El sistema debe ser capaz de operar con múltiples productores, múltiples consumidores, un broker central, una entidad bancaria simulada y una base de datos distribuida replicada.

El foco principal no es solamente vender entradas, sino demostrar:

- Tolerancia a fallos.
- Replicación de datos.
- Control de consistencia bajo reglas tipo DynamoDB.
- Prevención de sobreventa.
- Prevención de tickets duplicados.
- Recuperación de información histórica.
- Resincronización de nodos luego de fallos.
- Comunicación estrictamente mediante gRPC y Protocol Buffers.

## Idea central del sistema

DiscoPass simula una plataforma centralizada de eventos nocturnos. Las discotecas publican eventos con stock y precio. Los usuarios consultan esos eventos y solicitan compras. El broker central valida todo, coordina pagos, controla stock, genera tickets únicos y almacena los datos en una base distribuida compuesta por tres nodos.

Aunque existe un broker central, el almacenamiento no debe depender de un único nodo. Por eso, cada evento, compra, ticket y actualización de stock debe replicarse en tres nodos de base de datos usando:

- `N = 3`: número total de réplicas.
- `W = 2`: una escritura es válida si al menos dos nodos confirman.
- `R = 2`: una lectura histórica es válida si al menos dos nodos responden con datos coincidentes.

## Entidades del sistema

### Broker Central

El broker es el núcleo del sistema. Todas las entidades deben comunicarse con él, y ninguna entidad externa debe saltarse al broker.

Responsabilidades del broker:

- Registrar y autenticar discotecas, usuarios, nodos DB y banco.
- Rechazar mensajes de entidades no registradas.
- Recibir eventos publicados por discotecas.
- Validar eventos.
- Descartar eventos duplicados.
- Almacenar eventos en los nodos DB usando `N=3`, `W=2`.
- Recibir solicitudes de compra de usuarios.
- Validar existencia del evento.
- Validar stock disponible.
- Evitar compras duplicadas del mismo usuario para el mismo evento.
- Consultar al banco antes de aprobar una compra.
- Generar tickets únicos cuando la compra es aprobada.
- Actualizar stock de manera segura.
- Registrar compras, tickets y estados de pago en la base distribuida.
- Coordinar lecturas históricas usando `R=2`.
- Generar el archivo final `Reporte.txt`.

El broker debe ser el único responsable de generar tickets. Los usuarios no pueden crear tickets localmente.

### Productores: discotecas

Existen cuatro discotecas ficticias:

- DataClub.
- Dockers Night.
- GoLounge.
- GeorgieHouse.

Cada discoteca representa un productor independiente. Su tarea es generar eventos nocturnos de manera periódica y enviarlos al broker mediante gRPC.

Funciones de cada discoteca:

- Registrarse en el broker antes de enviar eventos.
- Generar eventos desde un catálogo base entregado por los ayudantes.
- Enviar eventos periódicamente, por ejemplo cada 30 a 40 segundos.
- Incluir un `evento_id` único para permitir idempotencia.
- Incluir datos válidos: nombre, categoría, comuna, precio, stock y fechas.
- Usar `time.Now()` en Go para la fecha de publicación o actualización.

Los eventos deben tener stock estrictamente mayor que cero y precio válido.

### Usuarios compradores

El sistema considera dos procesos de usuarios independientes:

- Cliente A.
- Cliente B.

Cada cliente representa usuarios que consultan eventos y solicitan compras. Deben operar como procesos aislados.

Responsabilidades de los usuarios:

- Registrarse en el broker antes de operar.
- Consultar eventos disponibles.
- Seleccionar eventos, posiblemente de manera aleatoria durante la simulación.
- Solicitar compra indicando obligatoriamente:
  - ID de usuario.
  - Medio de pago desde su configuración.
- Recibir respuesta de aprobación o rechazo.
- Guardar compras confirmadas en un archivo CSV propio.
- Recuperar historial de compras si se desconectan y luego vuelven.

Los usuarios deben manejar rechazos por:

- Evento inexistente.
- Evento no disponible.
- Falta de stock.
- Pago rechazado.
- Fallo temporal del servicio de pago.
- Compra duplicada del mismo usuario para el mismo evento.

### Banco USM

El banco es una entidad bancaria simulada. No necesita mantener saldos persistentes. Su comportamiento es probabilístico.

Reglas de aprobación:

- Regla general: aprobar 80% de las transacciones.
- Si el medio de pago es `crédito`: aprobar 90% de las transacciones.
- El resto debe rechazarse por fondos insuficientes.

El banco debe registrar logs por cada solicitud recibida:

- ID de usuario.
- Medio de pago.
- Monto.
- Resultado final: aprobado o rechazado.

El broker consulta al banco durante el proceso de compra. Si el banco aprueba, el broker continúa con la generación del ticket. Si rechaza, la compra termina como rechazada.

### Nodos de base de datos distribuida

Existen tres nodos:

- DB1.
- DB2.
- DB3.

Los nodos simulan una base distribuida con replicación eventual inspirada en DynamoDB.

Responsabilidades de cada nodo:

- Almacenar eventos.
- Almacenar compras.
- Almacenar tickets.
- Almacenar estados de pago.
- Confirmar escrituras con ACK.
- Responder lecturas históricas.
- Mantener stock actualizado.
- Recuperarse luego de fallos.
- Resincronizarse con los otros nodos al volver.

Fallos que deben soportar:

- Caída temporal de un nodo.
- Nodo desactualizado.
- Escrituras incompletas.
- Resincronización posterior.

Una escritura debe considerarse exitosa si al menos dos de los tres nodos responden correctamente. Una lectura histórica debe aceptarse si al menos dos nodos entregan información coincidente.

## Estructura esperada de un evento

Ejemplo conceptual:

```json
{
  "evento_id": "uuidv4",
  "discoteca": "DataClub",
  "nombre_evento": "Noche Reggaeton Old School",
  "categoria": "Electronica",
  "comuna": "Huechuraba",
  "precio": 12000,
  "stock": 300,
  "fecha_evento": "2025-10-20T23:00:00",
  "fecha_publicacion": "2025-10-10T18:30:00"
}
```

En la implementación no se debe depender de valores hardcodeados, porque la evaluación usará una configuración distinta.

## Categorías válidas

Los eventos deben pertenecer exclusivamente a una de estas categorías:

- Electrónica.
- Reggaetón.
- Pop.
- Techno.
- House.
- Urbana.
- Latina.
- Noche Universitaria.
- Fiesta Temática.
- Retro.
- Open Bar.
- VIP.

El broker debe rechazar cualquier evento con categoría no reconocida.

## Validaciones obligatorias del broker

### Validación de entidad

Antes de aceptar cualquier mensaje, el broker debe verificar que la entidad esté registrada.

Debe rechazar:

- Discotecas no registradas.
- Usuarios no registrados.
- Nodos DB no registrados.
- Banco no registrado o no disponible, según el flujo.

### Validación de evento

Un evento solo debe aceptarse si cumple:

- `evento_id` no vacío.
- `evento_id` no usado previamente.
- Discoteca registrada.
- Nombre de evento no vacío.
- Categoría válida.
- Comuna no vacía.
- Precio mayor que cero.
- Stock mayor que cero.
- Fecha válida.
- Fecha de publicación generada correctamente.

Si un evento es inválido, debe registrarse como rechazado para el reporte final.

### Idempotencia

Cada evento debe tener un identificador único. Si una discoteca vuelve a enviar un evento con el mismo `evento_id`, el broker debe descartarlo como duplicado.

La idempotencia evita que reintentos de red o publicaciones repetidas generen eventos duplicados en la plataforma.

## Algoritmo correcto de publicación de eventos

Flujo esperado:

1. La discoteca se registra en el broker.
2. La discoteca genera un evento desde su catálogo base.
3. La discoteca envía el evento al broker mediante gRPC.
4. El broker valida identidad de la discoteca.
5. El broker valida campos del evento.
6. El broker verifica que el `evento_id` no esté duplicado.
7. El broker envía el evento a DB1, DB2 y DB3.
8. Cada nodo DB intenta guardar el evento y responde ACK o error.
9. El broker cuenta ACKs.
10. Si recibe al menos dos ACKs, la escritura es exitosa.
11. Si recibe menos de dos ACKs, la escritura falla.
12. El broker registra estadísticas para `Reporte.txt`.

Pseudocódigo recomendado:

```text
publicar_evento(evento, discoteca_id):
    si discoteca_id no está registrada:
        rechazar("discoteca no registrada")

    si evento es inválido:
        rechazar("datos inválidos")

    si evento.evento_id ya existe:
        rechazar("evento duplicado")

    acks = 0
    para cada nodo en [DB1, DB2, DB3]:
        respuesta = nodo.guardar_evento(evento)
        si respuesta == ACK:
            acks++

    si acks >= W:
        marcar_evento_como_aceptado(evento)
        responder_ok()
    si no:
        marcar_evento_como_fallido(evento)
        responder_error()
```

## Algoritmo correcto de compra

La compra es el flujo más delicado porque debe evitar:

- Sobreventa.
- Tickets duplicados.
- Compras duplicadas.
- Stock inconsistente.
- Tickets generados sin pago aprobado.

Flujo esperado:

1. Usuario se registra en el broker.
2. Usuario consulta eventos.
3. Usuario selecciona un evento.
4. Usuario solicita compra indicando ID de usuario y medio de pago.
5. Broker valida que el usuario esté registrado.
6. Broker valida que el evento exista.
7. Broker valida que el usuario no haya comprado ya ese mismo evento.
8. Broker valida stock disponible.
9. Broker consulta al banco.
10. Banco aprueba o rechaza probabilísticamente.
11. Si banco rechaza, el broker registra rechazo y termina.
12. Si banco aprueba, el broker descuenta stock de forma controlada.
13. Broker genera un `ticket_id` único.
14. Broker registra compra, ticket, pago aprobado y stock actualizado en la base distribuida.
15. La escritura debe cumplir `W=2`.
16. Si la escritura cumple `W=2`, el broker responde al usuario con ticket.
17. El usuario guarda la compra confirmada en su CSV.

Pseudocódigo recomendado:

```text
comprar_entrada(usuario_id, evento_id, medio_pago):
    si usuario_id no está registrado:
        rechazar("usuario no registrado")

    evento = buscar_evento_en_memoria_o_db(evento_id)
    si evento no existe:
        rechazar("evento no disponible")

    si usuario_ya_compro_evento(usuario_id, evento_id):
        rechazar("compra duplicada")

    bloquear_evento(evento_id)

    si stock(evento_id) <= 0:
        desbloquear_evento(evento_id)
        rechazar("sin stock")

    resultado_pago = banco.validar_pago(usuario_id, evento.precio, medio_pago)

    si resultado_pago != aprobado:
        registrar_pago_rechazado()
        desbloquear_evento(evento_id)
        rechazar("pago rechazado")

    ticket_id = generar_ticket_unico()
    stock_actualizado = stock(evento_id) - 1

    compra = crear_compra(usuario_id, evento_id, ticket_id, aprobado)

    acks = replicar_compra_ticket_y_stock(compra, ticket_id, stock_actualizado)

    si acks >= W:
        actualizar_estado_local(evento_id, stock_actualizado)
        desbloquear_evento(evento_id)
        responder_ok(ticket_id)
    si no:
        registrar_compra_pendiente_o_fallida()
        desbloquear_evento(evento_id)
        responder_error("no se pudo confirmar escritura distribuida")
```

### Control de concurrencia para evitar sobreventa

Como Cliente A y Cliente B pueden comprar simultáneamente, el broker debe proteger el stock de cada evento. En Go, una solución razonable es usar `sync.Mutex` o un mapa de locks por `evento_id`.

La sección crítica debe cubrir:

- Verificación de stock.
- Consulta o decisión de compra.
- Descuento de stock.
- Generación de ticket.
- Registro distribuido de la compra.

La consulta al banco puede hacerse dentro del lock si se quiere máxima simplicidad y evitar carreras. Eso reduce paralelismo, pero es más seguro para el laboratorio. Si se hace fuera del lock, el broker debe volver a validar stock antes de confirmar la compra.

Para este laboratorio, se recomienda priorizar corrección sobre rendimiento.

## Escrituras distribuidas con N=3 y W=2

Toda escritura importante debe enviarse a los tres nodos:

- Publicación de eventos.
- Compra aprobada.
- Ticket generado.
- Actualización de stock.
- Estado de pago.

La operación se considera exitosa si al menos dos nodos responden ACK.

Casos esperados:

- DB1, DB2 y DB3 responden: escritura exitosa.
- DB1 y DB2 responden, DB3 falla: escritura exitosa.
- DB1 responde, DB2 y DB3 fallan: escritura fallida.
- Ningún nodo responde: escritura fallida.

Cuando un nodo no recibe una escritura, debe quedar pendiente para resincronización posterior.

## Lecturas distribuidas con R=2

Las lecturas históricas se usan especialmente cuando un consumidor se reintegra luego de haberse caído.

Flujo esperado:

1. Usuario reconectado solicita historial al broker.
2. Broker consulta al menos dos nodos DB.
3. Broker compara respuestas.
4. Si dos respuestas coinciden, devuelve historial.
5. Si no hay consenso, debe intentar consultar el tercer nodo o reportar inconsistencia.

Pseudocódigo recomendado:

```text
leer_historial(usuario_id):
    respuestas = []

    para cada nodo en [DB1, DB2, DB3]:
        respuesta = nodo.obtener_historial(usuario_id)
        si respuesta válida:
            agregar respuesta a respuestas

    si existen al menos 2 respuestas coincidentes:
        devolver respuesta consensuada

    si no:
        registrar_inconsistencia()
        devolver_error("no hay consenso R=2")
```

## Replicación eventual y resincronización

Si un nodo se cae, el sistema debe seguir funcionando mientras se cumpla `W=2`. Al volver, el nodo debe recuperar los datos que perdió.

La implementación puede usar una de estas estrategias:

- El broker mantiene un backlog de escrituras pendientes por nodo.
- Los nodos se sincronizan entre pares al volver.
- El nodo recuperado solicita al broker o a otros nodos todos los eventos, compras y tickets faltantes.

Para el laboratorio, una estrategia simple y clara es:

1. El broker detecta que un nodo no respondió.
2. El broker registra la escritura como pendiente para ese nodo.
3. Cuando el nodo vuelve a registrarse o responder, el broker le envía el backlog pendiente.
4. El nodo guarda los datos y responde ACK.
5. El broker registra que la resincronización fue exitosa.

Cada registro debería tener un identificador único para que reintentar la sincronización sea idempotente.

## Simulación de fallos

El enunciado pide observar fallos durante la ejecución.

Fallos mínimos esperados:

- Al menos un nodo DB debe fallar temporalmente.
- Uno o más usuarios pueden desconectarse durante consulta o compra.
- Puede simularse falla temporal del banco.
- Pueden existir replicaciones incompletas que luego se resincronicen.

El sistema debe seguir funcionando si:

- Para escrituras, al menos dos DB responden.
- Para lecturas históricas, al menos dos DB entregan datos coincidentes.

## Archivos de salida requeridos

### CSV por usuario

Cada usuario debe guardar sus compras confirmadas en un CSV propio.

Contenido sugerido:

```csv
usuario_id,evento_id,ticket_id,discoteca,nombre_evento,precio,medio_pago,fecha_compra
```

Solo deben guardarse compras confirmadas. No se deben guardar tickets rechazados o compras fallidas como confirmadas.

### Reporte.txt

El broker debe generar `Reporte.txt` al finalizar.

Debe incluir como mínimo:

#### 1. Resumen de discotecas

- Eventos enviados por cada discoteca.
- Eventos aceptados por el broker.
- Eventos rechazados por datos inválidos.
- Eventos rechazados por stock nulo.
- Eventos rechazados por identificadores duplicados.

#### 2. Estado de nodos DB

- Estado final de DB1, DB2 y DB3: activo, caído o recuperado.
- Escrituras exitosas.
- Escrituras fallidas.
- Cantidad de eventos almacenados en cada nodo.
- Cantidad de compras almacenadas en cada nodo.
- Cantidad de tickets almacenados en cada nodo.

#### 3. Resumen de compras y tickets

- Total de solicitudes de compra.
- Compras aprobadas.
- Compras rechazadas por falta de stock.
- Compras rechazadas por el servicio de pago.
- Total de tickets generados correctamente.
- Confirmación de CSV generado por cada usuario.

#### 4. Estado del servicio de pago

- Pagos aprobados.
- Pagos rechazados.
- Solicitudes fallidas o sin respuesta.

#### 5. Fallos y recuperaciones

- Nodos caídos.
- Usuarios desconectados.
- Fallas temporales del banco.
- Resultado de resincronización de DB.
- Recuperación de historial de usuarios desconectados.

#### 6. Conclusión

- Si el sistema se mantuvo disponible.
- Si respetó `N=3`, `W=2`, `R=2`.
- Si evitó sobreventa.
- Si evitó duplicación de tickets.
- Si recuperó historial sin pérdida de datos.

## Docker y distribución en máquinas virtuales

Todas las entidades deben ejecutarse en contenedores Docker independientes.

Distribución sugerida por el enunciado:

- MV1: Broker.
- MV2: Productores y DB3.
- MV3: Consumidores y DB2.
- MV4: Banco y DB1.

Se debe incluir un Makefile con atajos como:

```makefile
make docker-VM1
make docker-VM2
make docker-VM3
make docker-VM4
```

Cada entidad debe tener su propio contenedor. Docker es obligatorio; implementaciones sin Docker tienen nota 0.

## Restricciones de librerías

Las librerías de Go permitidas incluyen:

- `fmt`
- `log`
- `errors`
- `os`
- `io`
- `bufio`
- `time`
- `sync`
- `math/rand`
- `encoding/csv`
- `encoding/json`
- `net`
- `context`
- `flag`
- `strconv`
- `strings`
- `grpc`

También se permiten las necesarias para gRPC y Protocol Buffers.

Cualquier librería externa no mencionada debe consultarse con los ayudantes.

## Consideraciones importantes de diseño

### No hardcodear configuración

El enunciado advierte que durante la evaluación se usará una configuración distinta. Por lo tanto, no se deben hardcodear:

- Direcciones IP.
- Puertos.
- Nombres de archivos de configuración.
- Usuarios.
- Medios de pago.
- Catálogos de eventos.
- Discotecas más allá de lo que venga configurado, salvo que el laboratorio exija esas cuatro en el escenario base.

Lo correcto es cargar configuración desde archivos o flags.

### gRPC obligatorio

Todas las comunicaciones entre entidades deben usar gRPC y Protocol Buffers.

No se permite usar:

- RabbitMQ.
- Kafka.
- NATS.
- Colas externas.
- Comunicación directa por archivos compartidos para simular mensajes.

### Logs claros

Cada entidad debe generar logs útiles:

- Inicio de entidad.
- Registro en broker.
- Mensajes enviados y recibidos.
- Eventos aceptados o rechazados.
- Compras aprobadas o rechazadas.
- Pagos aprobados o rechazados.
- Fallos simulados.
- Recuperaciones.
- Resincronización.

## Propuesta de contratos gRPC

Una estructura razonable de servicios sería:

### Servicio del Broker

Métodos sugeridos:

- `RegisterDisco`.
- `RegisterUser`.
- `RegisterDBNode`.
- `RegisterBank`.
- `PublishEvent`.
- `ListEvents`.
- `BuyTicket`.
- `GetPurchaseHistory`.
- `ReportFailure`.

### Servicio de DB

Métodos sugeridos:

- `StoreEvent`.
- `StorePurchase`.
- `StoreTicket`.
- `UpdateStock`.
- `GetEvents`.
- `GetPurchaseHistory`.
- `SyncData`.
- `HealthCheck`.

### Servicio del Banco

Métodos sugeridos:

- `ValidatePayment`.
- `HealthCheck`.

## Modelo de datos recomendado

### Evento

Campos mínimos:

- `evento_id`.
- `discoteca`.
- `nombre_evento`.
- `categoria`.
- `comuna`.
- `precio`.
- `stock`.
- `fecha_evento`.
- `fecha_publicacion`.

### Compra

Campos mínimos:

- `compra_id`.
- `usuario_id`.
- `evento_id`.
- `ticket_id`.
- `medio_pago`.
- `monto`.
- `estado_pago`.
- `estado_compra`.
- `fecha_compra`.

### Ticket

Campos mínimos:

- `ticket_id`.
- `usuario_id`.
- `evento_id`.
- `compra_id`.
- `fecha_emision`.
- `estado`.

### Registro de pago

Campos mínimos:

- `pago_id`.
- `usuario_id`.
- `evento_id`.
- `monto`.
- `medio_pago`.
- `resultado`.
- `fecha`.

## Invariantes que el sistema debe cumplir

Estas reglas deben mantenerse siempre:

- Un evento aceptado debe estar replicado en al menos dos nodos.
- Una compra aprobada debe tener exactamente un ticket.
- Un ticket debe pertenecer a una única compra.
- Un usuario no debe comprar dos veces el mismo evento.
- El stock nunca debe ser negativo.
- No se debe vender si el pago fue rechazado.
- No se debe generar ticket si no hay pago aprobado.
- No se debe confirmar compra si la escritura distribuida no alcanzó `W=2`.
- Una lectura histórica solo debe devolverse si cumple `R=2`.
- Un nodo recuperado debe resincronizar datos faltantes.

## Funcionamiento correcto esperado de punta a punta

Una ejecución completa correcta debería verse así:

1. Se levantan contenedores Docker.
2. Broker inicia y queda escuchando.
3. DB1, DB2 y DB3 se registran en broker.
4. Banco se registra en broker.
5. Discotecas se registran en broker.
6. Usuarios se registran en broker.
7. Discotecas comienzan a publicar eventos periódicos.
8. Broker valida eventos y replica en DBs.
9. Usuarios consultan cartelera.
10. Usuarios solicitan compras.
11. Broker controla stock y evita duplicados.
12. Broker consulta banco.
13. Banco aprueba o rechaza según probabilidad.
14. Broker genera ticket solo si corresponde.
15. Broker replica compra, ticket y stock.
16. Usuario guarda compra confirmada en CSV.
17. Se simula caída de un nodo DB.
18. Sistema sigue operando mientras `W=2`.
19. Nodo DB vuelve.
20. Broker o nodos resincronizan datos faltantes.
21. Se simula desconexión de usuario.
22. Usuario vuelve y recupera historial usando lectura `R=2`.
23. Broker genera `Reporte.txt`.
24. Reporte demuestra disponibilidad, consistencia y ausencia de sobreventa.

## Riesgos frecuentes en la implementación

- Descontar stock antes de saber si el pago fue aprobado.
- Generar ticket antes de confirmar pago.
- Confirmar compra sin alcanzar `W=2`.
- No proteger stock contra compras concurrentes.
- No detectar eventos duplicados.
- Permitir categorías inválidas.
- No guardar estados de pagos rechazados para reporte.
- No registrar fallos ni recuperaciones.
- No implementar recuperación de historial.
- No usar Docker para cada entidad.
- Usar comunicación distinta a gRPC.
- Hardcodear datos que cambiarán en evaluación.

## Criterio práctico para saber si la solución está bien

La solución debería poder demostrar en logs y en `Reporte.txt` que:

- Las cuatro discotecas publicaron eventos.
- El broker aceptó eventos válidos y rechazó inválidos o duplicados.
- Los tres nodos DB participaron en replicación.
- El sistema soportó la caída temporal de un nodo.
- Las escrituras siguieron funcionando con dos nodos activos.
- El nodo caído se resincronizó al volver.
- Los usuarios pudieron comprar entradas.
- Algunas compras fueron rechazadas por pago o stock.
- Los tickets generados fueron únicos.
- El stock nunca quedó negativo.
- Los usuarios generaron CSV con compras confirmadas.
- Un usuario desconectado pudo recuperar su historial.
- El reporte final contiene estadísticas completas.

## Resumen técnico del algoritmo correcto

El sistema debe implementar un flujo de coordinación centralizado en el broker, con almacenamiento distribuido replicado. El broker actúa como serializador lógico de operaciones sensibles, especialmente compras. Para cada escritura, intenta persistir en tres réplicas y exige dos confirmaciones. Para cada lectura histórica, exige dos respuestas coincidentes. La disponibilidad se mantiene mientras existan suficientes réplicas activas para cumplir `W=2` o `R=2`.

La clave del algoritmo es separar claramente:

- Validación de identidad.
- Validación de datos.
- Control de idempotencia.
- Control de stock.
- Validación probabilística de pago.
- Generación exclusiva de tickets por parte del broker.
- Escritura replicada.
- Confirmación solo si se cumple quórum.
- Recuperación eventual de nodos desactualizados.

Si esas reglas se respetan, el sistema cumple con el propósito del laboratorio: mantenerse operativo frente a fallos parciales, evitar inconsistencias críticas y conservar información histórica sin pérdida relevante de datos.
