package main

import (
	"context"
	"encoding/csv"
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"math/rand"
	"os"
	"strconv"
	"time"

	pbRegister "dbnode/proto/grpc_register/proto"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/encoding"
)

type jsonCodec struct{}

func (jsonCodec) Name() string {
	return "json"
}

func (jsonCodec) Marshal(v any) ([]byte, error) {
	return json.Marshal(v)
}

func (jsonCodec) Unmarshal(data []byte, v any) error {
	return json.Unmarshal(data, v)
}

type Evento struct {
	EventID          string `json:"evento_id"`
	Discoteca        string `json:"discoteca"`
	NombreEvento     string `json:"nombre_evento"`
	Categoria        string `json:"categoria"`
	Comuna           string `json:"comuna"`
	Precio           int32  `json:"precio"`
	Stock            int32  `json:"stock"`
	FechaEvento      string `json:"fecha_evento"`
	FechaPublicacion string `json:"fecha_publicacion"`
}

type Compra struct {
	CompraID     string `json:"compra_id"`
	TicketID     string `json:"ticket_id"`
	UserID       string `json:"usuario_id"`
	EventID      string `json:"evento_id"`
	Discoteca    string `json:"discoteca"`
	NombreEvento string `json:"nombre_evento"`
	MedioPago    string `json:"medio_pago"`
	Monto        int32  `json:"monto"`
	FechaCompra  string `json:"fecha_compra"`
	EstadoPago   string `json:"estado_pago"`
	EstadoCompra string `json:"estado_compra"`
}

type ListarEventosRequest struct {
	UserID string `json:"usuario_id"`
}

type ListarEventosResponse struct {
	Success bool     `json:"success"`
	Message string   `json:"message"`
	Eventos []Evento `json:"eventos"`
}

type ComprarEntradaRequest struct {
	UserID    string `json:"usuario_id"`
	EventID   string `json:"evento_id"`
	MedioPago string `json:"medio_pago"`
}

type ComprarEntradaResponse struct {
	Success  bool    `json:"success"`
	Message  string  `json:"message"`
	TicketID string  `json:"ticket_id"`
	Compra   *Compra `json:"compra,omitempty"`
}

type HistorialRequest struct {
	UserID string `json:"usuario_id"`
}

type HistorialResponse struct {
	Success bool     `json:"success"`
	Message string   `json:"message"`
	Compras []Compra `json:"compras"`
}

type FalloRequest struct {
	Source    string `json:"source"`
	UserID    string `json:"usuario_id"`
	Type      string `json:"tipo"`
	Detail    string `json:"detalle"`
	Timestamp string `json:"timestamp"`
}

type FalloResponse struct {
	Success bool   `json:"success"`
	Message string `json:"message"`
}

type UsuarioServiceClient interface {
	ListarEventos(ctx context.Context, in *ListarEventosRequest, opts ...grpc.CallOption) (*ListarEventosResponse, error)
	ComprarEntrada(ctx context.Context, in *ComprarEntradaRequest, opts ...grpc.CallOption) (*ComprarEntradaResponse, error)
	ObtenerHistorial(ctx context.Context, in *HistorialRequest, opts ...grpc.CallOption) (*HistorialResponse, error)
	ReportarFallo(ctx context.Context, in *FalloRequest, opts ...grpc.CallOption) (*FalloResponse, error)
}

type usuarioServiceClient struct {
	cc grpc.ClientConnInterface
}

func NewUsuarioServiceClient(cc grpc.ClientConnInterface) UsuarioServiceClient {
	return &usuarioServiceClient{cc: cc}
}

func (c *usuarioServiceClient) ListarEventos(ctx context.Context, in *ListarEventosRequest, opts ...grpc.CallOption) (*ListarEventosResponse, error) {
	out := new(ListarEventosResponse)
	opts = append(opts, grpc.ForceCodec(jsonCodec{}))
	err := c.cc.Invoke(ctx, "/usuario.UsuarioService/ListarEventos", in, out, opts...)
	return out, err
}

func (c *usuarioServiceClient) ComprarEntrada(ctx context.Context, in *ComprarEntradaRequest, opts ...grpc.CallOption) (*ComprarEntradaResponse, error) {
	out := new(ComprarEntradaResponse)
	opts = append(opts, grpc.ForceCodec(jsonCodec{}))
	err := c.cc.Invoke(ctx, "/usuario.UsuarioService/ComprarEntrada", in, out, opts...)
	return out, err
}

func (c *usuarioServiceClient) ObtenerHistorial(ctx context.Context, in *HistorialRequest, opts ...grpc.CallOption) (*HistorialResponse, error) {
	out := new(HistorialResponse)
	opts = append(opts, grpc.ForceCodec(jsonCodec{}))
	err := c.cc.Invoke(ctx, "/usuario.UsuarioService/ObtenerHistorial", in, out, opts...)
	return out, err
}

func (c *usuarioServiceClient) ReportarFallo(ctx context.Context, in *FalloRequest, opts ...grpc.CallOption) (*FalloResponse, error) {
	out := new(FalloResponse)
	opts = append(opts, grpc.ForceCodec(jsonCodec{}))
	err := c.cc.Invoke(ctx, "/usuario.UsuarioService/ReportarFallo", in, out, opts...)
	return out, err
}

func main() {
	encoding.RegisterCodec(jsonCodec{})
	rand.Seed(time.Now().UnixNano())

	userID := flag.String("id", "usuario-1", "ID del usuario")
	brokerAddr := flag.String("broker", "localhost:50051", "Direccion del broker")
	medioPago := flag.String("medio", "debito", "Medio de pago: debito, credito, efectivo")
	interval := flag.Int("interval", 12, "Intervalo entre intentos de compra en segundos")
	maxCompras := flag.Int("max-compras", 0, "Cantidad maxima de compras confirmadas, 0 para infinito")
	disconnectAfter := flag.Int("disconnect-after", 0, "Iteracion en la que se simula desconexion, 0 desactiva")
	disconnectDuration := flag.Int("disconnect-duration", 15, "Duracion de desconexion simulada en segundos")
	flag.Parse()

	conn, err := grpc.Dial(*brokerAddr, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		log.Fatalf("[%s] No se pudo conectar al broker: %v", *userID, err)
	}
	defer conn.Close()

	registerClient := pbRegister.NewRegistrationServiceClient(conn)
	userClient := NewUsuarioServiceClient(conn)

	registerUser(*userID, registerClient)
	csvFile := fmt.Sprintf("%s.csv", sanitizeFileName(*userID))

	log.Printf("[%s] Usuario iniciado medio_pago=%s csv=%s", *userID, *medioPago, csvFile)

	iteration := 0
	confirmed := 0
	for {
		iteration++
		if *disconnectAfter > 0 && iteration == *disconnectAfter {
			reportFailure(userClient, *userID, "disconnect", "desconexion simulada del usuario")
			log.Printf("[%s] Desconexion simulada por %d segundos", *userID, *disconnectDuration)
			time.Sleep(time.Duration(*disconnectDuration) * time.Second)
			recoverHistory(userClient, *userID)
			reportFailure(userClient, *userID, "recovery", "usuario recupero historial despues de desconexion")
		}

		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		eventosResp, err := userClient.ListarEventos(ctx, &ListarEventosRequest{UserID: *userID})
		cancel()

		if err != nil {
			log.Printf("[%s] Error consultando eventos: %v", *userID, err)
			reportFailure(userClient, *userID, "list_events_error", err.Error())
			sleepInterval(*interval)
			continue
		}
		if !eventosResp.Success {
			log.Printf("[%s] Consulta rechazada: %s", *userID, eventosResp.Message)
			sleepInterval(*interval)
			continue
		}
		if len(eventosResp.Eventos) == 0 {
			log.Printf("[%s] No hay eventos disponibles", *userID)
			sleepInterval(*interval)
			continue
		}

		evento := eventosResp.Eventos[rand.Intn(len(eventosResp.Eventos))]
		log.Printf("[%s] Intentando compra evento=%s nombre=%s stock=%d precio=%d",
			*userID, evento.EventID, evento.NombreEvento, evento.Stock, evento.Precio)

		ctx, cancel = context.WithTimeout(context.Background(), 8*time.Second)
		buyResp, err := userClient.ComprarEntrada(ctx, &ComprarEntradaRequest{
			UserID:    *userID,
			EventID:   evento.EventID,
			MedioPago: *medioPago,
		})
		cancel()

		if err != nil {
			log.Printf("[%s] Error comprando evento=%s: %v", *userID, evento.EventID, err)
			reportFailure(userClient, *userID, "buy_error", err.Error())
			sleepInterval(*interval)
			continue
		}
		if !buyResp.Success {
			log.Printf("[%s] Compra rechazada evento=%s: %s", *userID, evento.EventID, buyResp.Message)
			sleepInterval(*interval)
			continue
		}
		if buyResp.Compra == nil {
			log.Printf("[%s] Compra aprobada sin detalle de compra", *userID)
			reportFailure(userClient, *userID, "missing_purchase_payload", "broker aprobo sin enviar compra")
			sleepInterval(*interval)
			continue
		}

		if err := appendCompraCSV(csvFile, buyResp.Compra); err != nil {
			log.Printf("[%s] Error guardando CSV: %v", *userID, err)
			reportFailure(userClient, *userID, "csv_error", err.Error())
		} else {
			confirmed++
			log.Printf("[%s] Compra confirmada ticket=%s guardada en %s", *userID, buyResp.TicketID, csvFile)
		}

		if *maxCompras > 0 && confirmed >= *maxCompras {
			log.Printf("[%s] Maximo de compras alcanzado: %d", *userID, confirmed)
			recoverHistory(userClient, *userID)
			return
		}

		sleepInterval(*interval)
	}
}

func registerUser(userID string, client pbRegister.RegistrationServiceClient) {
	for {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		resp, err := client.RegisterUser(ctx, &pbRegister.UserRegisterRequest{Userid: userID})
		cancel()
		if err != nil {
			log.Printf("[%s] Error registrando usuario: %v, reintento en 3s", userID, err)
			time.Sleep(3 * time.Second)
			continue
		}
		if !resp.GetSuccess() {
			log.Printf("[%s] Registro rechazado: %s, reintento en 3s", userID, resp.GetMessage())
			time.Sleep(3 * time.Second)
			continue
		}
		log.Printf("[%s] Registro aceptado: %s", userID, resp.GetMessage())
		return
	}
}

func appendCompraCSV(path string, compra *Compra) error {
	exists := false
	if _, err := os.Stat(path); err == nil {
		exists = true
	}

	file, err := os.OpenFile(path, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
	if err != nil {
		return err
	}
	defer file.Close()

	writer := csv.NewWriter(file)
	defer writer.Flush()

	if !exists {
		if err := writer.Write([]string{
			"usuario_id",
			"evento_id",
			"ticket_id",
			"compra_id",
			"discoteca",
			"nombre_evento",
			"medio_pago",
			"monto",
			"fecha_compra",
			"estado_pago",
			"estado_compra",
		}); err != nil {
			return err
		}
	}

	return writer.Write([]string{
		compra.UserID,
		compra.EventID,
		compra.TicketID,
		compra.CompraID,
		compra.Discoteca,
		compra.NombreEvento,
		compra.MedioPago,
		strconv.Itoa(int(compra.Monto)),
		compra.FechaCompra,
		compra.EstadoPago,
		compra.EstadoCompra,
	})
}

func recoverHistory(client UsuarioServiceClient, userID string) {
	ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
	resp, err := client.ObtenerHistorial(ctx, &HistorialRequest{UserID: userID})
	cancel()
	if err != nil {
		log.Printf("[%s] Error recuperando historial: %v", userID, err)
		reportFailure(client, userID, "history_error", err.Error())
		return
	}
	if !resp.Success {
		log.Printf("[%s] Historial no recuperado: %s", userID, resp.Message)
		reportFailure(client, userID, "history_rejected", resp.Message)
		return
	}
	log.Printf("[%s] Historial recuperado: %d compras", userID, len(resp.Compras))
}

func reportFailure(client UsuarioServiceClient, userID string, failureType string, detail string) {
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Second)
	defer cancel()
	_, err := client.ReportarFallo(ctx, &FalloRequest{
		Source:    "consumer",
		UserID:    userID,
		Type:      failureType,
		Detail:    detail,
		Timestamp: time.Now().Format(time.RFC3339),
	})
	if err != nil {
		log.Printf("[%s] No se pudo reportar fallo al broker: %v", userID, err)
	}
}

func sanitizeFileName(name string) string {
	clean := name
	replacements := []string{" ", "_", "/", "_", "\\", "_", ":", "_", "|", "_"}
	for i := 0; i < len(replacements); i += 2 {
		clean = replaceAll(clean, replacements[i], replacements[i+1])
	}
	return clean
}

func replaceAll(value string, old string, newValue string) string {
	for {
		next := ""
		changed := false
		for i := 0; i < len(value); i++ {
			if i+len(old) <= len(value) && value[i:i+len(old)] == old {
				next += newValue
				i += len(old) - 1
				changed = true
				continue
			}
			next += value[i : i+1]
		}
		if !changed {
			return value
		}
		value = next
	}
}

func sleepInterval(seconds int) {
	if seconds <= 0 {
		seconds = 1
	}
	time.Sleep(time.Duration(seconds) * time.Second)
}
