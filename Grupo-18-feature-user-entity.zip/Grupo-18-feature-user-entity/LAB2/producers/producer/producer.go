package main

import (
	"context"
	"encoding/json"
	"flag"
	"log"
	"math/rand"
	"os"
	"time"

	pbBroker "producer/proto/grpc_broker/proto"
	pbRegister "producer/proto/grpc_register/proto"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

type Eventos struct {
	EventoID         string `json:"evento_id"`
	Discoteca        string `json:"discoteca"`
	NombreEvento     string `json:"nombre_evento"`
	Categoria        string `json:"categoria"`
	Comuna           string `json:"comuna"`
	Precio           int32  `json:"precio"`
	Stock            int32  `json:"stock"`
	FechaEvento      string `json:"fecha_evento"`
	FechaPublicacion string `json:"fecha_publicacion"`
}

// =====================================================
// CARGAR Y FILTRAR JSON
// =====================================================

func cargarCatalogo(path string, discoName string) ([]Eventos, error) {

	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}

	var todos []Eventos
	err = json.Unmarshal(data, &todos)
	if err != nil {
		return nil, err
	}

	// Filtrar solo los eventos de esta discoteca
	var misCatalogo []Eventos
	for _, e := range todos {
		if e.Discoteca == discoName {
			misCatalogo = append(misCatalogo, e)
		}
	}

	return misCatalogo, nil
}

// =====================================================
// MAIN
// =====================================================

func main() {

	// =========================================
	// FLAGS — valores configurables al ejecutar
	// Ejemplo: ./producer -disco=GoLounge -broker=broker:50051
	// =========================================
	brokerAddr := flag.String("broker", "localhost:50051", "Dirección del broker")
	discoName := flag.String("disco", "DataClub", "Nombre de la discoteca")
	fileName := flag.String("archivo", "catalogo_eventos_40", "Nombre del archivo")
	flag.Parse()
	catalogPath := "json/" + *fileName + ".json"
	rand.Seed(time.Now().UnixNano())

	log.Printf("[%s] Iniciando productor", *discoName)

	// =========================================
	// CONEXIÓN AL BROKER
	// =========================================
	conn, err := grpc.Dial(
		*brokerAddr,
		grpc.WithTransportCredentials(insecure.NewCredentials()),
	)
	if err != nil {
		log.Fatalf("[%s] No se pudo conectar al broker: %v", *discoName, err)
	}
	defer conn.Close()

	registerClient := pbRegister.NewRegistrationServiceClient(conn)
	brokerClient := pbBroker.NewDiscotecaServiceClient(conn)

	// =========================================
	// CARGAR CATÁLOGO (solo eventos de esta disco)
	// =========================================
	catalogo, err := cargarCatalogo(catalogPath, *discoName)
	if err != nil {
		log.Fatalf("[%s] Error al cargar catálogo: %v", *discoName, err)
	}

	if len(catalogo) == 0 {
		log.Fatalf("[%s] No se encontraron eventos en el catálogo para esta discoteca", *discoName)
	}

	log.Printf("[%s] Catálogo cargado: %d eventos disponibles", *discoName, len(catalogo))

	// =========================================
	// REGISTRO EN EL BROKER (una sola vez)
	// =========================================
	registerResp, err := registerClient.RegisterDisco(
		context.Background(),
		&pbRegister.DiscoRegisterRequest{
			Name: *discoName,
		},
	)
	if err != nil {
		log.Fatalf("[%s] Error al registrarse en el broker: %v", *discoName, err)
	}
	if !registerResp.GetSuccess() {
		log.Printf("[%s] Aviso del broker: %s", *discoName, registerResp.GetMessage())
		log.Printf("[%s] Continuando operación...", *discoName)
	}

	log.Printf("[%s] Registrada en broker exitosamente", *discoName)

	// =========================================
	// LOOP CONTINUO DE PUBLICACIÓN
	// =========================================
	indice := 0
	for {
		base := catalogo[indice]
		indice = (indice + 1) % len(catalogo)

		ahora := time.Now().Format(time.RFC3339)

		resp, err := brokerClient.PublicarEvento(
			context.Background(),
			&pbBroker.PublicarEventoRequest{
				Eventid:          base.EventoID,
				Discoteca:        base.Discoteca,
				NombreEvento:     base.NombreEvento,
				Categoria:        base.Categoria,
				Comuna:           base.Comuna,
				Precio:           base.Precio,
				Stock:            base.Stock,
				FechaEvento:      base.FechaEvento,
				FechaPublicacion: ahora,
			},
		)

		if err != nil {
			log.Printf("[%s] Error publicando evento '%s': %v",
				*discoName, base.NombreEvento, err)
		} else {
			log.Printf("[%s] Evento '%s': %s",
				*discoName, base.NombreEvento, resp.GetMessage())
		}

		espera := 30 + rand.Intn(11)
		log.Printf("[%s] Próxima publicación en %d segundos...", *discoName, espera)
		time.Sleep(time.Duration(espera) * time.Second)
	}
}
