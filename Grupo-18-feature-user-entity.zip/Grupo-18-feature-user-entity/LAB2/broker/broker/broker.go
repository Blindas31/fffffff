package main

import (
	pbDatabase "broker/proto/grpc_database/proto"
	pbDisco "broker/proto/grpc_discoteca/proto"
	pbRegister "broker/proto/grpc_register/proto"
	"context"
	"encoding/json"
	"fmt"
	"log"
	"math/rand"
	"net"
	"os"
	"sort"
	"strings"
	"sync"
	"time"

	grpc "google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/encoding"
)

const (
	writeQuorum = 2
	readQuorum  = 2
)

type jsonCodec struct{}

func (jsonCodec) Name() string {
	return "json"
}

func (jsonCodec) Marshal(v any) ([]byte, error) {
	return json.Marshal(v)
}

func (jsonCodec) Unmarshal(data []byte, v any) error {
	return json.Unmarshal(data, v)
}

type Discoteca struct {
	EventID          string `json:"evento_id"`
	Discoteca        string `json:"discoteca"`
	NombreEvento     string `json:"nombre_evento"`
	Categoria        string `json:"categoria"`
	Comuna           string `json:"comuna"`
	Precio           int32  `json:"precio"`
	Stock            int32  `json:"stock"`
	FechaEvento      string `json:"fecha_evento"`
	FechaPublicacion string `json:"fecha_publicacion"`
}

type Compra struct {
	CompraID     string `json:"compra_id"`
	TicketID     string `json:"ticket_id"`
	UserID       string `json:"usuario_id"`
	EventID      string `json:"evento_id"`
	Discoteca    string `json:"discoteca"`
	NombreEvento string `json:"nombre_evento"`
	MedioPago    string `json:"medio_pago"`
	Monto        int32  `json:"monto"`
	FechaCompra  string `json:"fecha_compra"`
	EstadoPago   string `json:"estado_pago"`
	EstadoCompra string `json:"estado_compra"`
}

type Ticket struct {
	TicketID     string `json:"ticket_id"`
	CompraID     string `json:"compra_id"`
	UserID       string `json:"usuario_id"`
	EventID      string `json:"evento_id"`
	FechaEmision string `json:"fecha_emision"`
	Estado       string `json:"estado"`
}

type FailureEvent struct {
	Timestamp string `json:"timestamp"`
	Source    string `json:"source"`
	UserID    string `json:"usuario_id"`
	Type      string `json:"tipo"`
	Detail    string `json:"detalle"`
}

type ListarEventosRequest struct {
	UserID string `json:"usuario_id"`
}

type ListarEventosResponse struct {
	Success bool         `json:"success"`
	Message string       `json:"message"`
	Eventos []Discoteca  `json:"eventos"`
}

type ComprarEntradaRequest struct {
	UserID    string `json:"usuario_id"`
	EventID   string `json:"evento_id"`
	MedioPago string `json:"medio_pago"`
}

type ComprarEntradaResponse struct {
	Success  bool    `json:"success"`
	Message  string  `json:"message"`
	TicketID string  `json:"ticket_id"`
	Compra   *Compra `json:"compra,omitempty"`
}

type HistorialRequest struct {
	UserID string `json:"usuario_id"`
}

type HistorialResponse struct {
	Success bool     `json:"success"`
	Message string   `json:"message"`
	Compras []Compra `json:"compras"`
}

type FalloRequest struct {
	Source    string `json:"source"`
	UserID    string `json:"usuario_id"`
	Type      string `json:"tipo"`
	Detail    string `json:"detalle"`
	Timestamp string `json:"timestamp"`
}

type FalloResponse struct {
	Success bool   `json:"success"`
	Message string `json:"message"`
}

type UsuarioServiceServer interface {
	ListarEventos(context.Context, *ListarEventosRequest) (*ListarEventosResponse, error)
	ComprarEntrada(context.Context, *ComprarEntradaRequest) (*ComprarEntradaResponse, error)
	ObtenerHistorial(context.Context, *HistorialRequest) (*HistorialResponse, error)
	ReportarFallo(context.Context, *FalloRequest) (*FalloResponse, error)
}

type eventStats struct {
	SentByDisco       map[string]int
	AcceptedByDisco   map[string]int
	RejectedInvalid   int
	RejectedDuplicate int
	RejectedStock     int
	WriteFailures     int
}

type purchaseStats struct {
	Requests              int
	Approved              int
	RejectedNoStock       int
	RejectedPayment       int
	RejectedDuplicate     int
	RejectedInvalid       int
	DistributedFailures   int
	TicketsGenerated      int
	HistoryRecovered      int
	HistoryReadFailures   int
}

type paymentStats struct {
	Approved int
	Rejected int
	Failed   int
}

type dbNodeStats struct {
	Address       string
	RegisteredAt  string
	WriteOK       int
	WriteFailed   int
	ReadOK        int
	ReadFailed    int
	LastFailure   string
	LastRecovered string
}

type BrokerServer struct {
	pbRegister.UnimplementedRegistrationServiceServer
	pbDisco.UnimplementedDiscotecaServiceServer

	mutex            sync.Mutex
	registeredDiscos map[string]bool
	registeredUsers  map[string]bool
	registeredBanks  map[string]bool
	eventsMap        map[string]*Discoteca
	comprasMap       map[string]*Compra
	ticketsMap       map[string]*Ticket
	userEventBuys    map[string]bool
	failures         []FailureEvent
	dbClients        map[string]pbDatabase.DatabaseServiceClient
	dbStats          map[string]*dbNodeStats
	eventStats       eventStats
	purchaseStats    purchaseStats
	paymentStats     paymentStats
}

var categoriasValidas = map[string]bool{
	"Electronica":         true,
	"Reggaeton":           true,
	"Pop":                 true,
	"Techno":              true,
	"House":               true,
	"Urbana":              true,
	"Latina":              true,
	"Noche Universitaria": true,
	"Fiesta Tematica":     true,
	"Retro":               true,
	"Open Bar":            true,
	"VIP":                 true,
}

var discosValidas = map[string]bool{
	"DataClub":      true,
	"Dockers Night": true,
	"GoLounge":      true,
	"GeorgieHouse":  true,
}

func NewBrokerServer() *BrokerServer {
	return &BrokerServer{
		registeredDiscos: make(map[string]bool),
		registeredUsers:  make(map[string]bool),
		registeredBanks:  make(map[string]bool),
		eventsMap:        make(map[string]*Discoteca),
		comprasMap:       make(map[string]*Compra),
		ticketsMap:       make(map[string]*Ticket),
		userEventBuys:    make(map[string]bool),
		failures:         make([]FailureEvent, 0),
		dbClients:        make(map[string]pbDatabase.DatabaseServiceClient),
		dbStats:          make(map[string]*dbNodeStats),
		eventStats: eventStats{
			SentByDisco:     make(map[string]int),
			AcceptedByDisco: make(map[string]int),
		},
	}
}

func cloneDBClients(clients map[string]pbDatabase.DatabaseServiceClient) map[string]pbDatabase.DatabaseServiceClient {
	cloned := make(map[string]pbDatabase.DatabaseServiceClient, len(clients))
	for k, v := range clients {
		cloned[k] = v
	}
	return cloned
}

func (s *BrokerServer) recordFailureLocked(source string, userID string, failureType string, detail string) {
	failure := FailureEvent{
		Timestamp: time.Now().Format(time.RFC3339),
		Source:    source,
		UserID:    userID,
		Type:      failureType,
		Detail:    detail,
	}
	s.failures = append(s.failures, failure)
	log.Printf("[BROKER][FALLO] %s %s %s", source, failureType, detail)
}

func (s *BrokerServer) writeReportLocked() {
	var b strings.Builder
	now := time.Now().Format(time.RFC3339)

	b.WriteString("Reporte DiscoPass\n")
	b.WriteString("=================\n\n")
	b.WriteString(fmt.Sprintf("Generado: %s\n\n", now))

	b.WriteString("1. Resumen de Discotecas\n")
	for disco := range discosValidas {
		b.WriteString(fmt.Sprintf("- %s: enviados=%d aceptados=%d\n",
			disco,
			s.eventStats.SentByDisco[disco],
			s.eventStats.AcceptedByDisco[disco],
		))
	}
	b.WriteString(fmt.Sprintf("- Rechazados por datos invalidos: %d\n", s.eventStats.RejectedInvalid))
	b.WriteString(fmt.Sprintf("- Rechazados por stock invalido: %d\n", s.eventStats.RejectedStock))
	b.WriteString(fmt.Sprintf("- Rechazados por duplicado: %d\n", s.eventStats.RejectedDuplicate))
	b.WriteString(fmt.Sprintf("- Fallos de escritura de eventos: %d\n\n", s.eventStats.WriteFailures))

	b.WriteString("2. Estado de Nodos de Base de Datos\n")
	nodeIDs := make([]string, 0, len(s.dbStats))
	for nodeID := range s.dbStats {
		nodeIDs = append(nodeIDs, nodeID)
	}
	sort.Strings(nodeIDs)
	for _, nodeID := range nodeIDs {
		st := s.dbStats[nodeID]
		state := "activo"
		if st.LastFailure != "" && st.LastRecovered == "" {
			state = "con fallos recientes"
		}
		b.WriteString(fmt.Sprintf("- %s (%s): estado=%s write_ok=%d write_fail=%d read_ok=%d read_fail=%d\n",
			nodeID, st.Address, state, st.WriteOK, st.WriteFailed, st.ReadOK, st.ReadFailed,
		))
	}
	b.WriteString(fmt.Sprintf("- Eventos en memoria del broker: %d\n", len(s.eventsMap)))
	b.WriteString(fmt.Sprintf("- Compras confirmadas en memoria del broker: %d\n", len(s.comprasMap)))
	b.WriteString(fmt.Sprintf("- Tickets confirmados en memoria del broker: %d\n\n", len(s.ticketsMap)))

	b.WriteString("3. Resumen de Compras y Tickets\n")
	b.WriteString(fmt.Sprintf("- Solicitudes totales: %d\n", s.purchaseStats.Requests))
	b.WriteString(fmt.Sprintf("- Compras aprobadas: %d\n", s.purchaseStats.Approved))
	b.WriteString(fmt.Sprintf("- Rechazadas por falta de stock: %d\n", s.purchaseStats.RejectedNoStock))
	b.WriteString(fmt.Sprintf("- Rechazadas por pago: %d\n", s.purchaseStats.RejectedPayment))
	b.WriteString(fmt.Sprintf("- Rechazadas por compra duplicada: %d\n", s.purchaseStats.RejectedDuplicate))
	b.WriteString(fmt.Sprintf("- Rechazadas por solicitud invalida: %d\n", s.purchaseStats.RejectedInvalid))
	b.WriteString(fmt.Sprintf("- Fallas de escritura distribuida: %d\n", s.purchaseStats.DistributedFailures))
	b.WriteString(fmt.Sprintf("- Tickets generados correctamente: %d\n", s.purchaseStats.TicketsGenerated))
	b.WriteString(fmt.Sprintf("- Historiales recuperados: %d\n", s.purchaseStats.HistoryRecovered))
	b.WriteString(fmt.Sprintf("- Fallos de lectura historica: %d\n\n", s.purchaseStats.HistoryReadFailures))

	b.WriteString("4. Estado del Servicio de Pago\n")
	b.WriteString(fmt.Sprintf("- Pagos aprobados: %d\n", s.paymentStats.Approved))
	b.WriteString(fmt.Sprintf("- Pagos rechazados: %d\n", s.paymentStats.Rejected))
	b.WriteString(fmt.Sprintf("- Solicitudes fallidas o sin respuesta: %d\n\n", s.paymentStats.Failed))

	b.WriteString("5. Fallos y Recuperaciones\n")
	if len(s.failures) == 0 {
		b.WriteString("- No hay fallos registrados.\n")
	} else {
		for _, f := range s.failures {
			b.WriteString(fmt.Sprintf("- [%s] source=%s usuario=%s tipo=%s detalle=%s\n",
				f.Timestamp, f.Source, f.UserID, f.Type, f.Detail,
			))
		}
	}
	b.WriteString("\n")

	b.WriteString("6. Conclusion\n")
	b.WriteString("- El sistema confirma escrituras solo con W=2.\n")
	b.WriteString("- Las lecturas historicas de usuario exigen R=2.\n")
	b.WriteString("- El broker centraliza el descuento de stock y la generacion de tickets.\n")
	b.WriteString("- La sobreventa se evita rechazando compras sin stock y compras duplicadas por usuario/evento.\n")

	if err := os.WriteFile("Reporte.txt", []byte(b.String()), 0644); err != nil {
		log.Printf("[BROKER] Error escribiendo Reporte.txt: %v", err)
	}
}

func (s *BrokerServer) persistReport() {
	s.mutex.Lock()
	defer s.mutex.Unlock()
	s.writeReportLocked()
}

func (s *BrokerServer) RegisterDisco(ctx context.Context, req *pbRegister.DiscoRegisterRequest) (*pbRegister.RegisterResponse, error) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	discoteca := req.GetName()
	if discoteca == "" {
		return &pbRegister.RegisterResponse{Success: false, Message: "Discoteca no puede estar vacia"}, nil
	}
	if !discosValidas[discoteca] {
		log.Printf("[BROKER] Intento de registro de discoteca desconocida: %s", discoteca)
		return &pbRegister.RegisterResponse{Success: false, Message: "Discoteca no reconocida por el sistema"}, nil
	}
	if s.registeredDiscos[discoteca] {
		return &pbRegister.RegisterResponse{Success: true, Message: "Discoteca ya registrada"}, nil
	}

	s.registeredDiscos[discoteca] = true
	log.Printf("[BROKER] Discoteca registrada: %s", discoteca)
	s.writeReportLocked()
	return &pbRegister.RegisterResponse{Success: true, Message: "Discoteca registrada exitosamente"}, nil
}

func (s *BrokerServer) RegisterUser(ctx context.Context, req *pbRegister.UserRegisterRequest) (*pbRegister.RegisterResponse, error) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	userID := strings.TrimSpace(req.GetUserid())
	if userID == "" {
		return &pbRegister.RegisterResponse{Success: false, Message: "UserID requerido"}, nil
	}
	if s.registeredUsers[userID] {
		return &pbRegister.RegisterResponse{Success: true, Message: "Usuario ya registrado"}, nil
	}

	s.registeredUsers[userID] = true
	log.Printf("[BROKER] Usuario registrado: %s", userID)
	s.writeReportLocked()
	return &pbRegister.RegisterResponse{Success: true, Message: "Usuario registrado exitosamente"}, nil
}

func (s *BrokerServer) RegisterDB(ctx context.Context, req *pbRegister.DbRegisterRequest) (*pbRegister.RegisterResponse, error) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	nodeID := strings.TrimSpace(req.GetNodeid())
	addr := strings.TrimSpace(req.GetAdress())
	if nodeID == "" || addr == "" {
		return &pbRegister.RegisterResponse{Success: false, Message: "NodeID y direccion son requeridos"}, nil
	}

	conn, err := grpc.Dial(addr, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		log.Printf("[BROKER] No se pudo conectar al nodo %s en %s: %v", nodeID, addr, err)
		return &pbRegister.RegisterResponse{Success: false, Message: "No se pudo conectar al nodo"}, nil
	}

	s.dbClients[nodeID] = pbDatabase.NewDatabaseServiceClient(conn)
	st, exists := s.dbStats[nodeID]
	if !exists {
		st = &dbNodeStats{}
		s.dbStats[nodeID] = st
	}
	st.Address = addr
	st.RegisteredAt = time.Now().Format(time.RFC3339)
	st.LastRecovered = st.RegisteredAt

	log.Printf("[BROKER] Nodo DB registrado: %s en %s", nodeID, addr)
	s.writeReportLocked()
	return &pbRegister.RegisterResponse{Success: true, Message: "Nodo DB registrado exitosamente"}, nil
}

func (s *BrokerServer) RegisterBank(ctx context.Context, req *pbRegister.BancoRegisterResquest) (*pbRegister.RegisterResponse, error) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	bankID := strings.TrimSpace(req.GetBankid())
	if bankID == "" {
		return &pbRegister.RegisterResponse{Success: false, Message: "BankID requerido"}, nil
	}
	s.registeredBanks[bankID] = true
	log.Printf("[BROKER] Banco registrado: %s", bankID)
	s.writeReportLocked()
	return &pbRegister.RegisterResponse{Success: true, Message: "Banco registrado exitosamente"}, nil
}

func (s *BrokerServer) replicateWrite(clients map[string]pbDatabase.DatabaseServiceClient, operation string, id string, content string) bool {
	if len(clients) == 0 {
		log.Printf("[BROKER] No hay nodos DB registrados para %s %s", operation, id)
		s.eventStats.WriteFailures++
		return false
	}

	type result struct {
		nodeID string
		ok     bool
	}
	resultCh := make(chan result, len(clients))

	for nodeID, client := range clients {
		go func(nid string, c pbDatabase.DatabaseServiceClient) {
			ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
			defer cancel()

			req := &pbDatabase.WriteRequest{Id: id, Content: content}
			var resp *pbDatabase.WriteResponse
			var err error

			switch operation {
			case "evento":
				resp, err = c.WriteEvento(ctx, req)
			case "compra":
				resp, err = c.WriteCompra(ctx, req)
			case "ticket":
				resp, err = c.WriteTicket(ctx, req)
			default:
				err = fmt.Errorf("operacion desconocida: %s", operation)
			}

			if err != nil || resp == nil || !resp.GetSuccess() {
				log.Printf("[BROKER] Fallo escritura %s en nodo %s: %v", operation, nid, err)
				resultCh <- result{nodeID: nid, ok: false}
				return
			}

			resultCh <- result{nodeID: nid, ok: true}
		}(nodeID, client)
	}

	acks := 0
	for i := 0; i < len(clients); i++ {
		res := <-resultCh
		if st, exists := s.dbStats[res.nodeID]; exists {
			if res.ok {
				st.WriteOK++
				st.LastRecovered = time.Now().Format(time.RFC3339)
			} else {
				st.WriteFailed++
				st.LastFailure = time.Now().Format(time.RFC3339)
			}
		}
		if res.ok {
			acks++
		}
	}

	ok := acks >= writeQuorum
	log.Printf("[BROKER] Escritura %s %s: %d/%d ACKs (W=%d: %v)",
		operation, id, acks, len(clients), writeQuorum, ok)
	return ok
}

func (s *BrokerServer) writeEventoEnNodos(id string, content string) bool {
	s.mutex.Lock()
	clients := cloneDBClients(s.dbClients)
	s.mutex.Unlock()
	return s.replicateWrite(clients, "evento", id, content)
}

func (s *BrokerServer) PublicarEvento(ctx context.Context, req *pbDisco.PublicarEventoRequest) (*pbDisco.EventoPublicadoResponse, error) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	eventID := req.GetEventid()
	discoteca := req.GetDiscoteca()
	s.eventStats.SentByDisco[discoteca]++

	if eventID == "" {
		s.eventStats.RejectedInvalid++
		return &pbDisco.EventoPublicadoResponse{Success: false, Message: "EventID invalido"}, nil
	}
	if !discosValidas[discoteca] {
		s.eventStats.RejectedInvalid++
		return &pbDisco.EventoPublicadoResponse{Success: false, Message: "Discoteca no valida"}, nil
	}
	if !s.registeredDiscos[discoteca] {
		s.eventStats.RejectedInvalid++
		return &pbDisco.EventoPublicadoResponse{Success: false, Message: "Discoteca no registrada"}, nil
	}
	if _, exists := s.eventsMap[eventID]; exists {
		s.eventStats.RejectedDuplicate++
		return &pbDisco.EventoPublicadoResponse{Success: false, Message: "Evento ya publicado"}, nil
	}
	if req.GetPrecio() <= 0 {
		s.eventStats.RejectedInvalid++
		return &pbDisco.EventoPublicadoResponse{Success: false, Message: "Precio invalido"}, nil
	}
	if req.GetStock() <= 0 {
		s.eventStats.RejectedStock++
		return &pbDisco.EventoPublicadoResponse{Success: false, Message: "Stock invalido"}, nil
	}
	if !categoriasValidas[req.GetCategoria()] {
		s.eventStats.RejectedInvalid++
		return &pbDisco.EventoPublicadoResponse{Success: false, Message: "Categoria invalida"}, nil
	}

	newEvent := &Discoteca{
		EventID:          eventID,
		Discoteca:        discoteca,
		NombreEvento:     req.GetNombreEvento(),
		Categoria:        req.GetCategoria(),
		Comuna:           req.GetComuna(),
		Precio:           req.GetPrecio(),
		Stock:            req.GetStock(),
		FechaEvento:      req.GetFechaEvento(),
		FechaPublicacion: req.GetFechaPublicacion(),
	}

	jsonBytes, err := json.Marshal(newEvent)
	if err != nil {
		s.eventStats.RejectedInvalid++
		return &pbDisco.EventoPublicadoResponse{Success: false, Message: "No se pudo serializar evento"}, nil
	}

	clients := cloneDBClients(s.dbClients)
	ok := s.replicateWrite(clients, "evento", eventID, string(jsonBytes))
	if !ok {
		s.eventStats.WriteFailures++
		s.recordFailureLocked("broker", "", "write_evento", "evento "+eventID+" no alcanzo W=2")
		s.writeReportLocked()
		return &pbDisco.EventoPublicadoResponse{Success: false, Message: "Evento rechazado por replicacion incompleta"}, nil
	}

	s.eventsMap[eventID] = newEvent
	s.eventStats.AcceptedByDisco[discoteca]++
	log.Printf("[BROKER] Evento aceptado: %s - %s (stock: %d, precio: %d)",
		newEvent.NombreEvento, newEvent.Discoteca, newEvent.Stock, newEvent.Precio)
	s.writeReportLocked()

	return &pbDisco.EventoPublicadoResponse{Success: true, Message: "Evento publicado y replicado exitosamente"}, nil
}

func (s *BrokerServer) ListarEventos(ctx context.Context, req *ListarEventosRequest) (*ListarEventosResponse, error) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	userID := strings.TrimSpace(req.UserID)
	if userID == "" || !s.registeredUsers[userID] {
		return &ListarEventosResponse{Success: false, Message: "Usuario no registrado"}, nil
	}

	eventos := make([]Discoteca, 0, len(s.eventsMap))
	for _, event := range s.eventsMap {
		if event.Stock > 0 {
			eventos = append(eventos, *event)
		}
	}
	sort.Slice(eventos, func(i, j int) bool {
		return eventos[i].EventID < eventos[j].EventID
	})

	return &ListarEventosResponse{Success: true, Message: "Eventos disponibles", Eventos: eventos}, nil
}

func (s *BrokerServer) ComprarEntrada(ctx context.Context, req *ComprarEntradaRequest) (*ComprarEntradaResponse, error) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	s.purchaseStats.Requests++
	userID := strings.TrimSpace(req.UserID)
	eventID := strings.TrimSpace(req.EventID)
	medioPago := strings.TrimSpace(req.MedioPago)

	if userID == "" || !s.registeredUsers[userID] {
		s.purchaseStats.RejectedInvalid++
		return &ComprarEntradaResponse{Success: false, Message: "Usuario no registrado"}, nil
	}
	event, exists := s.eventsMap[eventID]
	if !exists {
		s.purchaseStats.RejectedInvalid++
		return &ComprarEntradaResponse{Success: false, Message: "Evento no disponible"}, nil
	}
	key := userID + "|" + eventID
	if s.userEventBuys[key] {
		s.purchaseStats.RejectedDuplicate++
		return &ComprarEntradaResponse{Success: false, Message: "Compra duplicada para el mismo usuario y evento"}, nil
	}
	if event.Stock <= 0 {
		s.purchaseStats.RejectedNoStock++
		return &ComprarEntradaResponse{Success: false, Message: "Compra rechazada por falta de stock"}, nil
	}

	if !s.validatePayment(medioPago) {
		s.paymentStats.Rejected++
		s.purchaseStats.RejectedPayment++
		log.Printf("[BROKER] Pago rechazado usuario=%s evento=%s medio=%s", userID, eventID, medioPago)
		s.writeReportLocked()
		return &ComprarEntradaResponse{Success: false, Message: "Pago rechazado por Banco USM"}, nil
	}

	now := time.Now().Format(time.RFC3339)
	compraID := fmt.Sprintf("compra-%s-%d", sanitizeID(userID), time.Now().UnixNano())
	ticketID := fmt.Sprintf("ticket-%s-%d", sanitizeID(userID), time.Now().UnixNano()+int64(rand.Intn(1000)))

	compra := &Compra{
		CompraID:     compraID,
		TicketID:     ticketID,
		UserID:       userID,
		EventID:      eventID,
		Discoteca:    event.Discoteca,
		NombreEvento: event.NombreEvento,
		MedioPago:    medioPago,
		Monto:        event.Precio,
		FechaCompra:  now,
		EstadoPago:   "aprobado",
		EstadoCompra: "confirmada",
	}
	ticket := &Ticket{
		TicketID:     ticketID,
		CompraID:     compraID,
		UserID:       userID,
		EventID:      eventID,
		FechaEmision: now,
		Estado:       "emitido",
	}
	updatedEvent := *event
	updatedEvent.Stock--
	updatedEvent.FechaPublicacion = now

	compraJSON, _ := json.Marshal(compra)
	ticketJSON, _ := json.Marshal(ticket)
	eventJSON, _ := json.Marshal(updatedEvent)

	clients := cloneDBClients(s.dbClients)
	compraOK := s.replicateWrite(clients, "compra", compraID, string(compraJSON))
	ticketOK := s.replicateWrite(clients, "ticket", ticketID, string(ticketJSON))
	eventOK := s.replicateWrite(clients, "evento", eventID, string(eventJSON))

	if !compraOK || !ticketOK || !eventOK {
		s.paymentStats.Approved++
		s.purchaseStats.DistributedFailures++
		s.recordFailureLocked("broker", userID, "write_compra", "compra "+compraID+" no pudo confirmar compra/ticket/stock con W=2")
		s.writeReportLocked()
		return &ComprarEntradaResponse{Success: false, Message: "Compra no confirmada por falla de escritura distribuida"}, nil
	}

	event.Stock--
	event.FechaPublicacion = now
	s.comprasMap[compraID] = compra
	s.ticketsMap[ticketID] = ticket
	s.userEventBuys[key] = true
	s.paymentStats.Approved++
	s.purchaseStats.Approved++
	s.purchaseStats.TicketsGenerated++

	log.Printf("[BROKER] Compra aprobada usuario=%s evento=%s ticket=%s stock_restante=%d",
		userID, eventID, ticketID, event.Stock)
	s.writeReportLocked()

	return &ComprarEntradaResponse{
		Success:  true,
		Message:  "Compra aprobada",
		TicketID: ticketID,
		Compra:   compra,
	}, nil
}

func (s *BrokerServer) validatePayment(medioPago string) bool {
	normalized := strings.ToLower(strings.TrimSpace(medioPago))
	approval := 80
	if normalized == "credito" || normalized == "credit" {
		approval = 90
	}
	return rand.Intn(100) < approval
}

func (s *BrokerServer) ObtenerHistorial(ctx context.Context, req *HistorialRequest) (*HistorialResponse, error) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	userID := strings.TrimSpace(req.UserID)
	if userID == "" || !s.registeredUsers[userID] {
		return &HistorialResponse{Success: false, Message: "Usuario no registrado"}, nil
	}

	clients := cloneDBClients(s.dbClients)
	if len(clients) < readQuorum {
		s.purchaseStats.HistoryReadFailures++
		s.recordFailureLocked("broker", userID, "read_historial", "no hay nodos suficientes para R=2")
		s.writeReportLocked()
		return &HistorialResponse{Success: false, Message: "No hay nodos suficientes para lectura R=2"}, nil
	}

	type readResult struct {
		nodeID   string
		ok       bool
		contents []string
	}
	resultCh := make(chan readResult, len(clients))

	for nodeID, client := range clients {
		go func(nid string, c pbDatabase.DatabaseServiceClient) {
			ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
			defer cancel()
			resp, err := c.ReadCompra(ctx, &pbDatabase.ReadRequest{Id: ""})
			if err != nil || resp == nil || !resp.GetSuccess() {
				resultCh <- readResult{nodeID: nid, ok: false}
				return
			}
			resultCh <- readResult{nodeID: nid, ok: true, contents: resp.GetContents()}
		}(nodeID, client)
	}

	signatures := make(map[string]int)
	signatureContents := make(map[string][]string)
	for i := 0; i < len(clients); i++ {
		res := <-resultCh
		if st, exists := s.dbStats[res.nodeID]; exists {
			if res.ok {
				st.ReadOK++
			} else {
				st.ReadFailed++
				st.LastFailure = time.Now().Format(time.RFC3339)
			}
		}
		if !res.ok {
			continue
		}

		filtered := filterCompraContentsByUser(res.contents, userID)
		sort.Strings(filtered)
		signature := strings.Join(filtered, "\n")
		signatures[signature]++
		signatureContents[signature] = filtered
	}

	for signature, count := range signatures {
		if count >= readQuorum {
			compras := decodeCompras(signatureContents[signature])
			s.purchaseStats.HistoryRecovered++
			s.writeReportLocked()
			return &HistorialResponse{Success: true, Message: "Historial recuperado con R=2", Compras: compras}, nil
		}
	}

	s.purchaseStats.HistoryReadFailures++
	s.recordFailureLocked("broker", userID, "read_historial", "no hubo consenso entre 2 nodos")
	s.writeReportLocked()
	return &HistorialResponse{Success: false, Message: "No fue posible recuperar historial con R=2"}, nil
}

func (s *BrokerServer) ReportarFallo(ctx context.Context, req *FalloRequest) (*FalloResponse, error) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	timestamp := req.Timestamp
	if timestamp == "" {
		timestamp = time.Now().Format(time.RFC3339)
	}
	failure := FailureEvent{
		Timestamp: timestamp,
		Source:    req.Source,
		UserID:    req.UserID,
		Type:      req.Type,
		Detail:    req.Detail,
	}
	s.failures = append(s.failures, failure)
	log.Printf("[BROKER][FALLO REPORTADO] source=%s usuario=%s tipo=%s detalle=%s",
		failure.Source, failure.UserID, failure.Type, failure.Detail)
	s.writeReportLocked()
	return &FalloResponse{Success: true, Message: "Fallo registrado en Reporte.txt"}, nil
}

func filterCompraContentsByUser(contents []string, userID string) []string {
	filtered := make([]string, 0)
	for _, content := range contents {
		var compra Compra
		if err := json.Unmarshal([]byte(content), &compra); err != nil {
			continue
		}
		if compra.UserID == userID {
			filtered = append(filtered, content)
		}
	}
	return filtered
}

func decodeCompras(contents []string) []Compra {
	compras := make([]Compra, 0, len(contents))
	for _, content := range contents {
		var compra Compra
		if err := json.Unmarshal([]byte(content), &compra); err == nil {
			compras = append(compras, compra)
		}
	}
	sort.Slice(compras, func(i, j int) bool {
		return compras[i].FechaCompra < compras[j].FechaCompra
	})
	return compras
}

func sanitizeID(id string) string {
	id = strings.TrimSpace(id)
	id = strings.ReplaceAll(id, " ", "_")
	id = strings.ReplaceAll(id, "|", "_")
	id = strings.ReplaceAll(id, "/", "_")
	id = strings.ReplaceAll(id, "\\", "_")
	return id
}

func RegisterUsuarioServiceServer(s grpc.ServiceRegistrar, srv UsuarioServiceServer) {
	s.RegisterService(&UsuarioService_ServiceDesc, srv)
}

func _UsuarioService_ListarEventos_Handler(srv any, ctx context.Context, dec func(any) error, interceptor grpc.UnaryServerInterceptor) (any, error) {
	in := new(ListarEventosRequest)
	if err := dec(in); err != nil {
		return nil, err
	}
	if interceptor == nil {
		return srv.(UsuarioServiceServer).ListarEventos(ctx, in)
	}
	info := &grpc.UnaryServerInfo{Server: srv, FullMethod: "/usuario.UsuarioService/ListarEventos"}
	handler := func(ctx context.Context, req any) (any, error) {
		return srv.(UsuarioServiceServer).ListarEventos(ctx, req.(*ListarEventosRequest))
	}
	return interceptor(ctx, in, info, handler)
}

func _UsuarioService_ComprarEntrada_Handler(srv any, ctx context.Context, dec func(any) error, interceptor grpc.UnaryServerInterceptor) (any, error) {
	in := new(ComprarEntradaRequest)
	if err := dec(in); err != nil {
		return nil, err
	}
	if interceptor == nil {
		return srv.(UsuarioServiceServer).ComprarEntrada(ctx, in)
	}
	info := &grpc.UnaryServerInfo{Server: srv, FullMethod: "/usuario.UsuarioService/ComprarEntrada"}
	handler := func(ctx context.Context, req any) (any, error) {
		return srv.(UsuarioServiceServer).ComprarEntrada(ctx, req.(*ComprarEntradaRequest))
	}
	return interceptor(ctx, in, info, handler)
}

func _UsuarioService_ObtenerHistorial_Handler(srv any, ctx context.Context, dec func(any) error, interceptor grpc.UnaryServerInterceptor) (any, error) {
	in := new(HistorialRequest)
	if err := dec(in); err != nil {
		return nil, err
	}
	if interceptor == nil {
		return srv.(UsuarioServiceServer).ObtenerHistorial(ctx, in)
	}
	info := &grpc.UnaryServerInfo{Server: srv, FullMethod: "/usuario.UsuarioService/ObtenerHistorial"}
	handler := func(ctx context.Context, req any) (any, error) {
		return srv.(UsuarioServiceServer).ObtenerHistorial(ctx, req.(*HistorialRequest))
	}
	return interceptor(ctx, in, info, handler)
}

func _UsuarioService_ReportarFallo_Handler(srv any, ctx context.Context, dec func(any) error, interceptor grpc.UnaryServerInterceptor) (any, error) {
	in := new(FalloRequest)
	if err := dec(in); err != nil {
		return nil, err
	}
	if interceptor == nil {
		return srv.(UsuarioServiceServer).ReportarFallo(ctx, in)
	}
	info := &grpc.UnaryServerInfo{Server: srv, FullMethod: "/usuario.UsuarioService/ReportarFallo"}
	handler := func(ctx context.Context, req any) (any, error) {
		return srv.(UsuarioServiceServer).ReportarFallo(ctx, req.(*FalloRequest))
	}
	return interceptor(ctx, in, info, handler)
}

var UsuarioService_ServiceDesc = grpc.ServiceDesc{
	ServiceName: "usuario.UsuarioService",
	HandlerType: (*UsuarioServiceServer)(nil),
	Methods: []grpc.MethodDesc{
		{MethodName: "ListarEventos", Handler: _UsuarioService_ListarEventos_Handler},
		{MethodName: "ComprarEntrada", Handler: _UsuarioService_ComprarEntrada_Handler},
		{MethodName: "ObtenerHistorial", Handler: _UsuarioService_ObtenerHistorial_Handler},
		{MethodName: "ReportarFallo", Handler: _UsuarioService_ReportarFallo_Handler},
	},
	Streams:  []grpc.StreamDesc{},
	Metadata: "usuario.proto",
}

func main() {
	rand.Seed(time.Now().UnixNano())
	encoding.RegisterCodec(jsonCodec{})

	lis, err := net.Listen("tcp", ":50051")
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}

	grpcServer := grpc.NewServer()
	brokerServer := NewBrokerServer()

	pbRegister.RegisterRegistrationServiceServer(grpcServer, brokerServer)
	pbDisco.RegisterDiscotecaServiceServer(grpcServer, brokerServer)
	RegisterUsuarioServiceServer(grpcServer, brokerServer)

	brokerServer.persistReport()
	go func() {
		ticker := time.NewTicker(20 * time.Second)
		defer ticker.Stop()
		for range ticker.C {
			brokerServer.persistReport()
		}
	}()

	log.Printf("[BROKER] Escuchando en :50051")
	if err := grpcServer.Serve(lis); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}
}
